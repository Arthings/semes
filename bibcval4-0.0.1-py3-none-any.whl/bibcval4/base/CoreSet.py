import torch
from torch import tensor
import numpy as np
from tqdm.auto import tqdm
import faiss
import torch.nn.functional as F
import pandas as pd
from typing import Tuple
import time
from typing import Callable

def old_euclidean_dist(x, y):
    m, n = x.size(0), y.size(0)
    xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
    yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
    dist = xx + yy
    # dist.addmm_(1, -2, x, y.t())
    dist = torch.addmm(dist, x, y.t(), alpha=1, beta=-2)
    dist = dist.clamp(min=1e-12).sqrt()
    return dist


def euclidean_dist(x, y):
    x = x.detach().cpu().numpy()
    y = y.detach().cpu().numpy()
    index = faiss.IndexFlatL2(x.shape[1])
    index.add(y)
    _, dist = index.search(x, 1)
    return torch.from_numpy(np.sqrt(dist))


def cosine_dist(x, y):
    x = x.detach().cpu().numpy()
    y = y.detach().cpu().numpy()

    # Normalize the vectors
    x = x / np.linalg.norm(x, axis=1, keepdims=True)
    y = y / np.linalg.norm(y, axis=1, keepdims=True)

    index = faiss.IndexFlatIP(x.shape[1])
    index.add(y)
    _, dist = index.search(x, 1)
    return torch.from_numpy(dist)


def cosine_distance(vector1, vector2):
    # Normalize vectors
    vector1 = F.normalize(vector1, p=2, dim=0)
    vector2 = F.normalize(vector2, p=2, dim=0)

    # Compute cosine similarity
    cosine_similarity = torch.dot(vector1, vector2)

    # Convert cosine similarity to cosine distance
    cosine_distance = 1 - cosine_similarity.item()
    return cosine_distance


def cossim(v1: tensor, v2: tensor) -> float:
    num = torch.matmul(v1, v2.T)
    denom = torch.norm(v1, dim=1).view(-1, 1) * torch.norm(v2, dim=1)
    res = num / denom
    res[torch.isneginf(res)] = 0.0
    return 0.5 + 0.5 * res


def cosdist(v1, v2):
    num = torch.matmul(v1, v2.T)
    denom = torch.norm(v1, dim=1).view(-1, 1) * torch.norm(v2, dim=1)
    res = num / denom
    res[torch.isneginf(res)] = 0.0
    return -(0.5 + 0.5 * res)


def k_center_greedy(
    matrix,
    budget: int,
    metric,
    device,
    random_seed=None,
    index=None,
    already_selected=[],
):
    if matrix is torch.Tensor:
        assert matrix.dim() == 2
        matrix = matrix.requires_grad_(False).to(device)
    elif matrix is np.ndarray:
        assert matrix.ndim == 2
        matrix = torch.from_numpy(matrix).requires_grad_(False).to(device)

    sample_num = matrix.shape[0]
    assert sample_num >= 1

    if budget < 0:
        raise ValueError("Illegal budget size.")
    elif budget > sample_num:
        budget = sample_num

    if index is not None:
        assert matrix.shape[0] == len(index)
    else:
        index = np.arange(sample_num)

    assert callable(metric)
    assert len(already_selected) > 0

    already_selected = np.array(already_selected)

    select_result = np.in1d(index, already_selected)

    num_of_already_selected = np.sum(select_result)

    # Initialize a (num_of_already_selected+budget-1)*sample_num matrix storing distances of pool points from
    # each clustering center.
    dis_matrix = (
        -1
        * torch.ones(
            [num_of_already_selected + budget - 1, sample_num], requires_grad=False
        ).cpu()
    )

    dis_matrix[:num_of_already_selected, ~select_result] = metric(
        matrix[select_result], matrix[~select_result]
    ).cpu()
    scores = torch.zeros(budget)

    mins = torch.min(dis_matrix[:num_of_already_selected, :], dim=0).values
    assert (mins[num_of_already_selected:] < 0).sum().item() == 0, (
        f"The distance function should be worked on, some distances are negative {(mins[num_of_already_selected:]<0).sum()=}"
    )
    print_freq = budget // 100 if budget > 10 else 1
    for i in range(budget):
        if i % print_freq == 0:
            print("| Selecting [%3d/%3d]" % (i + 1, budget))
        p = torch.argmax(mins).item()
        select_result[p] = True

        if i == budget - 1:
            break
        scores[i] = mins[p]
        mins[p] = -1
        dis_matrix[num_of_already_selected + i, ~select_result] = metric(
            matrix[[p]], matrix[~select_result]
        ).cpu()
        mins = torch.min(mins.cpu(), dis_matrix[num_of_already_selected + i]).cuda(0)

    return index[select_result], scores


def furthest_first(unlabeled_embeddings, labeled_embeddings, device, budget):
    unlabeled_embeddings = torch.from_numpy(unlabeled_embeddings).to(device)
    labeled_embeddings = torch.from_numpy(labeled_embeddings).to(device)

    m = unlabeled_embeddings.shape[0]

    if labeled_embeddings.shape[0] == 0:
        min_dist = torch.tile(float("inf"), m)
    else:
        dist_ctr = torch.cdist(unlabeled_embeddings, labeled_embeddings, p=2)
        min_dist = torch.min(dist_ctr, dim=1)[0]

    idxs = np.zeros(budget)

    i = 0
    for i in tqdm(range(budget), desc="Finding a core-set of items."):
        idx = torch.argmax(min_dist)
        idxs[i] = idx.item()
        dist_new_ctr = torch.cdist(unlabeled_embeddings, unlabeled_embeddings[[idx], :])
        min_dist = torch.minimum(min_dist, dist_new_ctr[:, 0])

    return idxs

def gpu_compute_dists(M1,M2):
    """
    Computes L2 norm square on gpu
    Assume 
    M1: M x D matrix
    M2: N x D matrix

    output: M x N matrix
    """
    #print(f"Function call to gpu_compute dists; M1: {M1.shape} and M2: {M2.shape}")
    M1_norm = (M1**2).sum(1).reshape(-1,1)

    M2_t = torch.transpose(M2, 0, 1)
    M2_norm = (M2**2).sum(1).reshape(1,-1)
    dists = M1_norm + M2_norm - 2.0 * torch.mm(M1, M2_t)
    return dists

def greedy_k_center(
    labeled: np.ndarray, 
    unlabeled: np.ndarray,
    budget:int,
):
    greedy_indices = [None for i in range(budget)]
    greedy_indices_counter = 0
    # move cpu to gpu
    labeled = torch.from_numpy(labeled).cuda(0)
    unlabeled = torch.from_numpy(unlabeled).cuda(0)

    print(f"[GPU] Labeled.shape: {labeled.shape}")
    print(f"[GPU] Unlabeled.shape: {unlabeled.shape}")
    # get the minimum distances between the labeled and unlabeled examples (iteratively, to avoid memory issues):
    st = time.time()

    min_dist, _ = torch.min(
        gpu_compute_dists(labeled[0, :].reshape((1, labeled.shape[1])), unlabeled),
        dim=0,
    )

    min_dist = torch.reshape(min_dist, (1, min_dist.shape[0]))
    print(f"time taken: {time.time() - st} seconds")
    distances = np.zeros(len(greedy_indices))
    temp_range = 500
    dist = np.empty((temp_range, unlabeled.shape[0]))
    for j in tqdm(
        range(1, labeled.shape[0], temp_range), desc="Getting first farthest index"
    ):
        if j + temp_range < labeled.shape[0]:
            dist = gpu_compute_dists(labeled[j : j + temp_range, :], unlabeled)
        else:
            dist = gpu_compute_dists(labeled[j:, :], unlabeled)

        min_dist = torch.cat(
            (min_dist, torch.min(dist, dim=0)[0].reshape((1, min_dist.shape[1])))
        )

        min_dist = torch.min(min_dist, dim=0)[0]
        min_dist = torch.reshape(min_dist, (1, min_dist.shape[0]))

    # iteratively insert the farthest index and recalculate the minimum distances:
    _, farthest = torch.max(min_dist, dim=1)
    greedy_indices[greedy_indices_counter] = farthest.item()
    greedy_indices_counter += 1

    amount = budget - 1

    

    for i in tqdm(range(amount), desc="Constructing Active set"):
        dist = gpu_compute_dists(
            unlabeled[greedy_indices[greedy_indices_counter - 1], :].reshape(
                (1, unlabeled.shape[1])
            ),
            unlabeled,
        )

        min_dist = torch.cat((min_dist, dist.reshape((1, min_dist.shape[1]))))

        min_dist, _ = torch.min(min_dist, dim=0)
        min_dist = min_dist.reshape((1, min_dist.shape[0]))
        farthest_distance, farthest = torch.max(min_dist, dim=1)
        greedy_indices[greedy_indices_counter] = farthest.item()
        distances[greedy_indices_counter] = farthest_distance.item()
        greedy_indices_counter += 1

    remainSet = set(np.arange(unlabeled.shape[0])) - set(greedy_indices)
    remainSet = np.array(list(remainSet))

    return greedy_indices, distances


def optimal_greedy_k_center(budget: int, labeled: np.ndarray, unlabeled: np.ndarray):
    def compute_dists(X, X_train):
        dists = (
            -2 * np.dot(X, X_train.T)
            + np.sum(X_train**2, axis=1)
            + np.sum(X**2, axis=1).reshape((-1, 1))
        )
        return dists

    n_lSet = labeled.shape[0]
    lSetIds = np.arange(n_lSet)

    # order is important
    features = np.vstack((labeled, unlabeled))
    distance_mat = compute_dists(features, features)
    print(
        "Started computing distance matrix of {}x{}".format(
            features.shape[0], features.shape[0]
        )
    )

    greedy_indices = []
    for i in tqdm(range(budget), desc="Finding a typiclust coreset"):
        lab_temp_indexes = np.array(np.append(lSetIds, greedy_indices), dtype=int)
        min_dist = np.min(distance_mat[lab_temp_indexes, n_lSet:], axis=0)
        active_index = np.argmax(min_dist)
        greedy_indices.append(n_lSet + active_index)

    remainSet = set(np.arange(features.shape[0])) - set(greedy_indices) - set(lSetIds)
    remainSet = np.array(list(remainSet))

    return greedy_indices, remainSet


def greedy_k_center_(
    budget: int, labeled: np.matrix, unlabeled: np.matrix, device, isMIP: bool = False
) -> Tuple:
    def gpu_compute_dists(M1, M2):
        """
        Computes L2 norm square on gpu
        Assume
        M1: M x D matrix
        M2: N x D matrix

        output: M x N matrix
        """
        # print(f"Function call to gpu_compute dists; M1: {M1.shape} and M2: {M2.shape}")
        M1_norm = (M1**2).sum(1).reshape(-1, 1)

        M2_t = torch.transpose(M2, 0, 1)
        M2_norm = (M2**2).sum(1).reshape(1, -1)
        dists = M1_norm + M2_norm - 2.0 * torch.mm(M1, M2_t)
        return dists

    greedy_indices = [None for i in range(budget)]
    greedy_indices_counter = 0
    # move cpu to gpu
    labeled = torch.from_numpy(labeled).to(device)
    unlabeled = torch.from_numpy(unlabeled).to(device)

    print(f"[GPU] Labeled.shape: {labeled.shape}")
    print(f"[GPU] Unlabeled.shape: {unlabeled.shape}")
    # get the minimum distances between the labeled and unlabeled examples (iteratively, to avoid memory issues):
    min_dist, _ = torch.min(
        gpu_compute_dists(labeled[0, :].reshape((1, labeled.shape[1])), unlabeled),
        dim=0,
    )
    min_dist = torch.reshape(min_dist, (1, min_dist.shape[0]))

    temp_range = 500
    dist = np.empty((temp_range, unlabeled.shape[0]))
    for j in tqdm(
        range(1, labeled.shape[0], temp_range), desc="Getting first farthest index"
    ):
        if j + temp_range < labeled.shape[0]:
            dist = gpu_compute_dists(labeled[j : j + temp_range, :], unlabeled)
        else:
            dist = gpu_compute_dists(labeled[j:, :], unlabeled)

        min_dist = torch.cat(
            (min_dist, torch.min(dist, dim=0)[0].reshape((1, min_dist.shape[1])))
        )

        min_dist = torch.min(min_dist, dim=0)[0]
        min_dist = torch.reshape(min_dist, (1, min_dist.shape[0]))

    # iteratively insert the farthest index and recalculate the minimum distances:
    _, farthest = torch.max(min_dist, dim=1)
    greedy_indices[greedy_indices_counter] = farthest.item()
    greedy_indices_counter += 1

    amount = budget - 1

    for i in tqdm(range(amount), desc="Constructing Active set"):
        dist = gpu_compute_dists(
            unlabeled[greedy_indices[greedy_indices_counter - 1], :].reshape(
                (1, unlabeled.shape[1])
            ),
            unlabeled,
        )

        min_dist = torch.cat((min_dist, dist.reshape((1, min_dist.shape[1]))))

        min_dist, _ = torch.min(min_dist, dim=0)
        min_dist = min_dist.reshape((1, min_dist.shape[0]))
        _, farthest = torch.max(min_dist, dim=1)
        greedy_indices[greedy_indices_counter] = farthest.item()
        greedy_indices_counter += 1

    remainSet = set(np.arange(unlabeled.shape[0])) - set(greedy_indices)
    remainSet = np.array(list(remainSet))
    if isMIP:
        return greedy_indices, remainSet, np.sqrt(min_dist.max().item())
    else:
        return greedy_indices, remainSet


if __name__ == "__main__":
    from accelerate import Accelerator

    accelerator = Accelerator()
    m = np.random.rand(1000, 518)
    # m = np.random.rand(1000,2)

    m = pd.DataFrame(m)

    a = k_center_greedy(
        matrix=m.values,
        budget=100,
        metric=cosine_dist,
        accelerator=accelerator,
        already_selected=[],
    )
