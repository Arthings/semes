from .embeddings import compute_embeddings, compute_embeddings_instance
from .CoreSet import greedy_k_center
from .baseStrat import baseStrat
