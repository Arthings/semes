import torch
import os
import numpy as np
from typing import Optional
from ..utils import make_determinist
from tqdm.auto import tqdm
from torch.utils.data import DataLoader
from ..utils import maskrcnn_collate_fn

@torch.no_grad()
def compute_embeddings(
    model,
    D: torch.utils.data.Dataset,
    config,
    logger,
    precomputed_features: Optional[str],
    seed=None,
) -> np.ndarray:
    """load or compute the embeddings of full dataset depending on the precomputed feature attribute."""

    if precomputed_features is not None:
        print(precomputed_features)
        precomputed_features_folder = "/".join(precomputed_features.split("/")[:-1])
        assert os.path.exists(precomputed_features), (
            f"{precomputed_features} doesn't exists. There are only : {os.listdir(precomputed_features_folder)}"
        )
        return np.load(precomputed_features)

    else:
        bs = config.batch_size

        # Now we compute the full matrix, But we should be able to compute the matrix only for the labeled and unlabeled items. (in case of subset)
        # loader = DataLoader(D, batch_size=32, sampler = SubsetLinearSampler(np.concatenate([labeled_indexes, unlabeled_indexes])))
        loader = DataLoader(
            D, 
            num_workers = config.workers, 
            batch_size = bs, 
            shuffle = False
        )

        d_model = model.cuda(0)

        number_of_items = len(D)

        d_model.eval()
        images, _ = d_model.prepare_batch(next(iter(loader)))

        embeddings = d_model.forward_embedding(images.cuda(0)).cuda(0).float()

        assert len(embeddings.shape) == 2, (
            f"Embeddings shoud have 2 dimension, but got {embeddings.shape}"
        )
        assert embeddings.isnan().sum() == 0, (
            f"Embeddings contains {embeddings.isnan().sum()} nan values"
        )

        embedding_size = embeddings.shape[1]
        logger.info(f"Embedding dimension : {embedding_size}")

        feature_matrix = torch.zeros(
            # the size of the embedding is dynamicaly read from the model as long as the embedding is from the input of the last fully connected layer
            (number_of_items, embedding_size)
        )

        feature_matrix = feature_matrix.cuda(0)

        i = 0
        for batches in tqdm(loader, desc="Computing images embeddings ..."):
            imgs, targets = d_model.prepare_batch(batches)

            bs = len(imgs)
            features = d_model.forward_embedding(imgs.cuda(0))

            assert features.isnan().sum() == 0, f"{features.isnan().sum()} nan features"
            # we should detach de tensors since we only need the features vectors
            feature_matrix[i : i + bs] = features
            i += bs

        assert feature_matrix.shape[0] == number_of_items, (
            f"{number_of_items=}, and {features.shape[0]}"
        )

        return feature_matrix.detach().cpu().numpy()



@torch.no_grad()
def compute_embeddings_instance(
    model,
    D: torch.utils.data.Dataset,
    config,
    logger,
    precomputed_features: Optional[str],
    seed=None,
) -> np.ndarray:
    """load or compute the embeddings of full dataset depending on the precomputed feature attribute."""

    if seed is not None:
        make_determinist(seed)

    if precomputed_features is not None:
        print(precomputed_features)
        precomputed_features_folder = "/".join(precomputed_features.split("/")[:-1])
        assert os.path.exists(precomputed_features), (
            f"{precomputed_features} doesn't exists. There are only : {os.listdir(precomputed_features_folder)}"
        )
        return np.load(precomputed_features)

    else:
        bs = config.batch_size

        # Now we compute the full matrix, But we should be able to compute the matrix only for the labeled and unlabeled items. (in case of subset)
        # loader = DataLoader(D, batch_size=32, sampler = SubsetLinearSampler(np.concatenate([labeled_indexes, unlabeled_indexes])))
        loader = DataLoader(
            D, 
            num_workers = config.workers, 
            batch_size = bs, 
            shuffle = False,
            collate_fn=maskrcnn_collate_fn,
        )

        d_model = model.cuda(0)

        number_of_items = len(D)

        d_model.eval()
        images, _ = d_model.prepare_batch(next(iter(loader)))
        images = [i.cuda(0) for i in images]
        
        embeddings = d_model.forward_embedding(images).cuda(0).float()

        assert len(embeddings.shape) == 2, (
            f"Embeddings shape should be 2, but got {embeddings.shape}"
        )
        assert embeddings.isnan().sum() == 0, (
            f"Embeddings contains {embeddings.isnan().sum()} nan values"
        )

        embedding_size = embeddings.shape[1]
        logger.info(f"Embedding dimension : {embedding_size}")

        feature_matrix = torch.zeros(
            # the size of the embedding is dynamicaly read from the model as long as the embedding is from the input of the last fully connected layer
            (number_of_items, embedding_size)
        )

        feature_matrix = feature_matrix.cuda(0)

        i = 0
        for batches in tqdm(loader, desc="Computing images embeddings ..."):
            imgs, targets = d_model.prepare_batch(batches)

            bs = len(imgs)
            imgs = [i.cuda(0) for i in imgs]
            features = d_model.forward_embedding(imgs)

            assert features.isnan().sum() == 0, f"{features.isnan().sum()} nan features"
            # we should detach de tensors since we only need the features vectors
            feature_matrix[i : i + bs] = features
            i += bs

        assert feature_matrix.shape[0] == number_of_items, (
            f"{number_of_items=}, and {features.shape[0]}"
        )
        logger.info(f"Embeddings matrix shape {feature_matrix.shape=}")

        return feature_matrix.detach().cpu()


    
def get_representation(
    model,
    D: torch.utils.data.Dataset,
    config,
    logger,
    precomputed_features: Optional[str],
    seed=None, 
):

    model.cuda(0)
    loader = DataLoader(
        D, 
        num_workers = config.workers, 
        batch_size = config.batch_size, 
        shuffle = False,
    )
    features = []
    
    print(f"len(dataLoader): {len(loader)}")

    for i, batch in enumerate(tqdm(loader, desc="Extracting Representations")):
        x,_ = model.prepare_batch(batch)
        with torch.no_grad():
            x = x.cuda(0)
            x = x.type(torch.cuda.FloatTensor)
            temp_z = model.forward_embedding(x)
            features.append(temp_z.cpu().numpy())

    features = np.concatenate(features, axis=0)

    logger.info(f"Embeddings matrix shape {features.shape=}")

    return features