from dataclasses import dataclass
from typing import Dict, Optional, Callable, List
from torch.utils.data import DataLoader, Dataset, Subset
import numpy as np 
import lightning as L
import torch
from omegaconf import DictConfig
from logging import Logger
from abc import ABC, abstractmethod
from .embeddings import compute_embeddings, compute_embeddings_instance, get_representation
from ..active_learning import ActiveLearningDataset
"""
baseStrat is the object from which inherit all strategies.

It contains all the data required to compute selection strategies.
Ut is instanciated in the al_loop function.

"""
@dataclass
class baseStrat(ABC):
    base_dataset: ActiveLearningDataset
    val_loader: DataLoader
    model: L.LightningModule
    config: DictConfig
    logger: Logger
    budget: int
    cycles: int
    save_freq: int = -1
    precomputed_features: Optional[str] = None # path to a numpy file with embeddings


    def __post_init__(self):
        self.repetitions = self.config.repetitions
        self.base_dataset_index = self.base_dataset.names
        self.labeled_indices = self.base_dataset.labeled_indices
        self.unlabeled_indices = self.base_dataset.unlabeled_indices
    
    @abstractmethod
    @torch.no_grad()
    def select(self, unlabeled_subset:np.ndarray):
        pass

    @torch.no_grad()
    def compute_embeddings_on_subset(self, subset = None)->np.ndarray:
        dataset = self.base_dataset if subset is None else Subset(self.base_dataset, subset)
         
        # return compute_embeddings(
        return get_representation(
            model = self.model,
            D = dataset,
            config=self.config,
            logger=self.logger,
            seed = self.config.seed,
            precomputed_features=self.precomputed_features
        )

    def convert_instance(self, child_class):
        """
        Create a new instance of the given child class with the same attributes as the current instance.

        Args:
            child_class (type): The child class to create an instance of.

        Returns:
            baseStrat: A new instance of the child class.
        """
        new_instance = child_class(
            base_dataset=self.base_dataset,
            model=self.model,
            config=self.config,
            logger=self.logger,
            precomputed_features=self.precomputed_features
        )
        return new_instance

if __name__ == "__main__":
    pass