import torch
from scipy.stats import entropy
import numpy as np
from tqdm.auto import tqdm
from torch.utils.data import DataLoader
from ..utils.SubsetLinearSampling import SubsetLinearSampler

from ..base import baseStrat
from dataclasses import dataclass
from torchcp.classification.score import RAPS
from torchcp.classification.predictor import SplitPredictor
from ..classification import AVAILABLE_SCORING_FUNCTIONS as classif_functions
from copy import deepcopy
import os
import math 
from typing import List, Any, Iterable

"""
A scoring function must have the following signature

f(
    D,
    labeled_indexes,
    unlabeled,
    budget,
    model,
    config,
    accelerator,
    logger,
    precomputed_features:str,
    hook_process_func:Callable,
)

the function must output a bibcvdataset which contains only the items to label




in this problem, the output is a mask if dimension [B, 1, H, W] where we classify pixels into one class.
The case where the output is a lsit of masks correpsonding to multiple classes is not implemented.

Thus, OCC only implemented so far
"""


def entropy_gpu(pk, base:int =torch.e):
    """Compute entropy using pytorch function avoiding data transfert between devices

    Args:
        pk (_type_): _description_
        base (int, optional): _description_. Defaults to torch.e.

    Returns:
        _type_: _description_
    """    
    assert len(pk.shape) == 4, "Should provide a batch of images"
    assert math.isclose(pk.sum(dim = 1).mean(), 1, rel_tol=1/1000), f"Should provide probabilities for each class on dimension 1 (channel dimension), {pk.sum(dim = 1).mean()}"
    return -(pk * pk.log()).sum(dim = 1) / np.log(base)

def maskrcnn_collate_fn(batchs: List[Any]):
    """We need to define a custom collate function to handle bboxes that can be different size.

    Documentation :
            https://pytorch.org/tutorials/intermediate/torchvision_tutorial.html
    The maskrcnn is expecting :
        image = a List of Images
        target = a list of dictionnary containing :
            - boxes
            - masks
            - labels
            - image_id

    Args:
        batch (List[Any]): _description_

    Returns:
        Tuple(Images,Targets):
    """
    images = []
    targets = []
    for i, item in enumerate(batchs):
        c, h, w = item["image"].shape
        images.append(item["image"])
        target = dict(
            boxes=torch.zeros((0, 4)),
            masks=torch.zeros((0, h, w)),
            labels=torch.zeros((0,), dtype=torch.int64),
            image_id=item["name"],
        )
        # We override with annotation when there are.
        if len(item["labels"]) > 0:
            for key in ["boxes", "masks", "labels"]:
                if isinstance(item[key], list):
                    if isinstance(item[key][0], Iterable):
                        # case list of tensor/np.array/list/tuple
                        if isinstance(item[key][0], torch.Tensor):
                            target[key] = torch.stack(item[key])
                        else:
                            target[key] = torch.stack(
                                [torch.tensor(k) for k in item[key]]
                            )
                    else:
                        # case list of int
                        target[key] = torch.tensor(item[key])
                else:
                    # case numpy array or tensor
                    target[key] = torch.tensor(item[key])
        targets.append(target)
    return images, targets


# ==================================================================================================
#                   Baseline
# ==================================================================================================


@dataclass
class randomSampling(baseStrat):
    def select(self, unlabeled_subset):
        selected = np.random.choice(unlabeled_subset, self.budget, replace=False)
        return selected.astype(int)


# ==================================================================================================
#                   Exploitation Strategies
# ==================================================================================================


@torch.no_grad()
def entropy_from_probtensor(t: torch.tensor) -> torch.tensor:
    """Compute the entropy for each probs output of a batch

    Args:
        t (torch.tensor): Batch of output B C H W
            Where C is the number of classes.
            IF C == 1 the output is converted into a multiclass output where C = 2

    Returns:
        torch.tensor: B 1 H W
    """
    assert len(t.shape) == 4, "you should provide a batch"

    if t.shape[1] == 1:
        # occ classification
        b = 1 - t
        c = torch.cat((t, b), axis=1)

        assert c.shape[0] == t.shape[0]
        assert c.shape[1] == 2

        # c = c.detach().cpu()  # B 2 H W
    else:
        # c = t.detach().cpu()  # B C H W
        c = t
        pass

    entropies = entropy_gpu(c)  # B 1 H W

    assert entropies.shape[0] == t.shape[0]

    return entropies

@dataclass
class entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),

        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda(0)
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Entropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            scores[i : i + bs] = entropy_from_probtensor(outputs).mean(dim=[1, 2])
            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs

        self.logger.info(
            f"{scores.mean()=} {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        torch.save(scores, os.path.join(self.config.log_dir + "/scores.pt"))
        torch.save(selected, os.path.join(self.config.log_dir + "/selected.pt"))

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected
@dataclass
class topkentropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        pixel_pct = 0.2
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda()
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using TopKEntropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            h = imgs.shape[2]
            w = imgs.shape[3]

            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            images_entropy = entropy_from_probtensor(outputs)
            topk_entropies = torch.topk(
                images_entropy.view(bs, -1), k=int(pixel_pct * h * w), dim=1
            ).values
            scores[i : i + bs] = topk_entropies.mean(dim=1)


            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs


        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected

@dataclass
class top10entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        pixel_pct = 0.1
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda()
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Top10Entropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            h = imgs.shape[2]
            w = imgs.shape[3]

            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            images_entropy = entropy_from_probtensor(outputs)
            topk_entropies = torch.topk(
                images_entropy.view(bs, -1), k=int(pixel_pct * h * w), dim=1
            ).values
            scores[i : i + bs] = topk_entropies.mean(dim=1)


            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs


        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected

@dataclass
class top10copyentropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        pixel_pct = 0.1
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda()
        d_model = self.model.cuda(0)

        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Top10copyEntropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            h = imgs.shape[2]
            w = imgs.shape[3]

            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            images_entropy = entropy_from_probtensor(outputs)
            topk_entropies = torch.topk(
                images_entropy.view(bs, -1), k=int(pixel_pct * h * w), dim=1
            ).values
            scores[i : i + bs] = topk_entropies.mean(dim=1)


            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs


        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected

@dataclass
class top25entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        pixel_pct = 0.25
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda()
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Top25Entropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            h = imgs.shape[2]
            w = imgs.shape[3]

            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            images_entropy = entropy_from_probtensor(outputs)
            topk_entropies = torch.topk(
                images_entropy.view(bs, -1), k=int(pixel_pct * h * w), dim=1
            ).values
            scores[i : i + bs] = topk_entropies.mean(dim=1)


            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs


        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected

@dataclass
class top50entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        pixel_pct = 0.50
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda()
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Top50Entropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            h = imgs.shape[2]
            w = imgs.shape[3]

            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            images_entropy = entropy_from_probtensor(outputs)
            topk_entropies = torch.topk(
                images_entropy.view(bs, -1), k=int(pixel_pct * h * w), dim=1
            ).values
            scores[i : i + bs] = topk_entropies.mean(dim=1)


            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs


        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected


@dataclass
class top75entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        pixel_pct = 0.75
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda(0)
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Top75Entropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            h = imgs.shape[2]
            w = imgs.shape[3]

            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            images_entropy = entropy_from_probtensor(outputs)
            topk_entropies = torch.topk(
                images_entropy.view(bs, -1), k=int(pixel_pct * h * w), dim=1
            ).values
            
            scores[i : i + bs] = topk_entropies.mean(dim=1)


            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs

        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected


@dataclass
class top100entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        pixel_pct = 1
        assert pixel_pct <= 1
        
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda()
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Top100Entropy"
        ):
            imgs, target = self.model.prepare_batch(batchs)
            bs = len(imgs)
            h = imgs.shape[2]
            w = imgs.shape[3]

            imgs = imgs.cuda(0)
            outputs = d_model.forward_proba(imgs)

            images_entropy = entropy_from_probtensor(outputs)
            topk_entropies = torch.topk(
                images_entropy.view(bs, -1), k=int(pixel_pct * h * w), dim=1
            ).values
            scores[i : i + bs] = topk_entropies.mean(dim=1)


            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"

            i += bs


        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )
        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]

        return selected


@torch.no_grad()
def calibrate(model, cal_loader, alpha: int = 0.05):
    """_summary_

    Args:
        model (_type_): _description_
        cal_loader (_type_): _description_
        alpha (int, optional): _description_. Defaults to .05.

    Returns:
        _type_: _description_

    """
    cal_logits = []
    cal_labels = []
    d_model = model.cuda(0)
    d_model.eval()
    for batches in tqdm(cal_loader, desc="Calibrating ..."):
        cal_logits.append(d_model(batches["image"].cuda()))
        cal_labels.append(batches["mask"].cuda())

    cal_logits = torch.concat(cal_logits)
    print(f"{cal_logits.shape=}")
    num_classes = cal_logits.shape[1]

    if num_classes == 1:
        # Binary case
        if (cal_logits.max() > 1) or (cal_logits.min() < 0):
            cal_logits = cal_logits.sigmoid()
        # We stack these because CP algo needs
        cal_logits = torch.stack([(1 - cal_logits).flatten(), cal_logits.flatten()]).T
    else:
        cal_logits = (
            cal_logits.permute(1, 0, 2, 3).reshape(num_classes, -1).T
        )

    cal_labels = torch.concat(cal_labels).flatten()

    predictor = SplitPredictor(RAPS(penalty=0), model)
    assert len(cal_logits) == len(cal_labels), (
        f"logits and labels have different sizes {len(cal_logits)=}, {len(cal_labels)=}"
    )
    predictor.calculate_threshold(cal_logits, cal_labels, alpha)
    return predictor

@dataclass
class cpSetsSampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )
        calibrated_predictor = calibrate(self.model, self.val_loader, alpha=0.05) # by default we set risk alpha to 5%
        scores = torch.zeros(len(unlabeled_subset))

        i = 0
        model = self.model.cuda(0)
        model.eval()
        for batches in tqdm(unlab_loader, desc="Scoring using conformal prediction..."):
            images, masks = model.prepare_batch(batches)
            val_logits = model(images.cuda(0))
            # i do this image image by image to be sure to classify each images.
            if val_logits.shape[1] == 1:  # binary segmentation case
                for image_output, _ in zip(val_logits, masks):
                    image_logits = torch.stack(
                        [
                            (1 - image_output.sigmoid()).flatten(),
                            image_output.flatten().sigmoid(),
                        ]
                    ).T

                    prediction_sets = calibrated_predictor.predict_with_logits(
                        image_logits
                    )

                    # the certain items are the one where the prediciton sets are full of the same category (i.e std == 0) and don't belong to the background (class_id == 0)
                    number_of_sure_foreground_pixels = torch.logical_and(
                        prediction_sets.float().std(dim=1).eq(0),
                        prediction_sets.sum(dim=1).not_equal(0),
                    ).sum()
                    scores[i] = prediction_sets.float().std(dim=1).sum() / (
                        number_of_sure_foreground_pixels + 1e-5
                    )
                    i += 1
            else:  # multiclass semantic segmentation
                for image_output, _ in zip(val_logits, masks):
                    prediction_sets = calibrated_predictor.predict_with_logits(
                        image_output
                    )
                    # the certain items are the one where the prediciton sets are full of the same category (i.e std == 0)
                    number_of_sure_foreground_pixels = torch.logical_and(
                        prediction_sets.float().std(dim=1).eq(0),
                        prediction_sets.sum(dim=1).not_equal(0),
                    ).sum()
                    scores[i] = prediction_sets.float().std(dim=1).sum() / (
                        number_of_sure_foreground_pixels + 1e-5
                    )
                    i += 1

        selected = torch.topk(scores, self.budget).indices
        selected = unlabeled_subset[selected]
        return selected

@dataclass
class cpSetsSamplingRatio(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        bs = self.config.batch_size
        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=bs,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )
        calibrated_predictor = calibrate(self.model, self.val_loader, alpha=0.05)
        scores = torch.zeros(len(unlabeled_subset))

        i = 0
        model = self.model.cuda(0)
        model.eval()
        for batches in tqdm(unlab_loader, desc="Scoring using conformal prediction..."):
            images, masks = model.prepare_batch(batches)
            val_logits = model(images.cuda(0))
            if val_logits.shape[1] == 1:  # binary segmentation case
                for image_output, mask in zip(val_logits, masks):
                    image_logits = torch.stack(
                        [
                            (1 - image_output.sigmoid()).flatten(),
                            image_output.flatten().sigmoid(),
                        ]
                    ).T

                    prediction_sets = calibrated_predictor.predict_with_logits(
                        image_logits
                    )

                    scores[i] = prediction_sets.float().std(dim=1).sum()
                    i += 1
            else:  # multiclass semantic segmentation
                for image_output, mask in zip(val_logits, masks):
                    prediction_sets = calibrated_predictor.predict_with_logits(
                        image_logits
                    )
                    scores[i] = prediction_sets.float().std(dim=1).sum()
                    i += 1

        selected = torch.topk(scores, self.budget).indices
        selected = unlabeled_subset[selected]
        return selected


# ==================================================================================================
#                   Exploration Strategies
# ==================================================================================================


deepcoresetSampling: baseStrat = classif_functions["deepcoresetSampling"]
typiclustSampling: baseStrat = classif_functions["typiclustSampling"]

@dataclass
class TMSSampling(baseStrat):
    def select(self, unlabeled_subset):
        tp_sampling = self.convert_instance(typiclustSampling)
        entropy_sampling = self.convert_instance(entropySampling)

        if self.config.current_cycle < self.config.cycles // 2:
            return entropy_sampling.select(unlabeled_subset)
        else:
            return tp_sampling.select(unlabeled_subset)


AVAILABLE_SCORING_FUNCTIONS = {
    # baseline
    "randomSampling": randomSampling,
    # exploitation
    "topkentropySampling": topkentropySampling,
    "top25entropySampling": top25entropySampling,
    "top10entropySampling": top10entropySampling,
    "top10copyentropySampling": top10copyentropySampling,
    "top50entropySampling": top50entropySampling,
    "top75entropySampling": top75entropySampling,
    "top100entropySampling" : top100entropySampling,
    "entropySampling": entropySampling,
    "cpSetsSampling": cpSetsSampling,
    # exploration
    "deepcoresetSampling": deepcoresetSampling,
    "typiclustSampling": typiclustSampling,
    # mixte
    "TMSSampling": TMSSampling,
}
    