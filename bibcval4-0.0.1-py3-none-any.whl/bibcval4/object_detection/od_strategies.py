import torch
import numpy as np
from tqdm.auto import tqdm
from torch.utils.data import DataLoader, Subset, SequentialSampler

from ..base import baseStrat
from dataclasses import dataclass
import math
from ..classification import AVAILABLE_SCORING_FUNCTIONS as classif_functions
from typing import List
from ..base.CoreSet import k_center_greedy
from ..base.embeddings import compute_embeddings_instance

"""

in this problem, the output is a mask if dimension [B, 1, H, W] where we classify pixels into one class.
The case where the output is a lsit of masks correpsonding to multiple classes is not implemented.

Thus, OCC only implemented so far
"""

# ==================================================================================================
#                   Baseline
# ==================================================================================================


@dataclass
class randomSampling(baseStrat):
    def select(self, unlabeled_subset):
        selected = np.random.choice(unlabeled_subset, self.budget, replace=False)
        return selected.astype(int)


# ==================================================================================================
#                   Exploitation Strategies
# ==================================================================================================
def entropy_gpu(pk, base: int = torch.e):
    """Compute entropy using pytorch function avoiding data transfert between devices

    Args:
        pk (_type_): _description_
        base (int, optional): _description_. Defaults to torch.e.

    Returns:
        _type_: _description_
    """
    assert len(pk.shape) == 4, "Should provide a batch of images"
    assert math.isclose(pk.sum(dim=1).mean(), 1, rel_tol=1 / 1000), (
        f"Should provide probabilities for each class on dimension 1 (channel dimension), {pk.sum(dim=1).mean()}"
    )
    return -(pk * pk.log()).sum(dim=1) / np.log(base)


def crop_image_tensor(image_tensor, bounding_boxes):
    """
    Crop a tensor image using bounding box coordinates.

    Args:
        image_tensor (torch.Tensor): The input image tensor of shape (C, H, W).
        bounding_boxes (torch.Tensor): A tensor of shape (N, 4) containing:
                                        [[x_min, y_min, x_max, y_max], ...]

    Returns:
        list: A list of cropped image tensors.
    """
    crops = []

    for box in bounding_boxes:
        x_min, y_min, x_max, y_max = box

        # Ensure coordinates are within tensor dimensions
        h, w = image_tensor.shape[1], image_tensor.shape[2]
        x_min = max(0, min(x_min, w))
        y_min = max(0, min(y_min, h))
        x_max = max(x_min, min(x_max, w))
        y_max = max(y_min, min(y_max, h))

        # Crop the tensor using indexing
        crop = image_tensor[:, y_min:y_max, x_min:x_max]
        crops.append(crop)

    return crops


@torch.no_grad()
def entropy_from_probtensor(t: torch.tensor) -> torch.tensor:
    """Compute the entropy for each probs output of a batch

    Args:
        t (torch.tensor): Batch of output B C H W
            Where C is the number of classes.
            IF C == 1 the output is converted into a multiclass output where C = 2

    Returns:
        torch.tensor: B
    """
    if t.nelement() == 0:
        # if the boxes are empty, we return 0
        return torch.zeros(0)
    assert len(t.shape) == 4, "you should provide a batch"

    if t.shape[1] == 1:
        # occ classification
        b = 1 - t
        c = torch.cat((t, b), axis=1)

        assert c.shape[0] == t.shape[0]
        assert c.shape[1] == 2

        # c = c.detach().cpu()  # B 2 H W
    else:
        # c = t.detach().cpu()  # B C H W
        c = t
        pass

    entropies = entropy_gpu(c)  # B 1 H W
    if entropies.isnan().sum() > 0:
        entropies = entropy_gpu(c)
    assert entropies.shape[0] == t.shape[0]

    return entropies


@torch.no_grad()
def entropy_od(output):
    bs = len(output)

    batch_scores = torch.zeros(bs)

    for i, images in enumerate(output):
        detections = len(images["labels"])
        if detections == 0:
            batch_scores[i] = torch.rand(1)
            # TODO : how to score images with no detection ? what uncertainty could we assign
        else:

            # the higher the score the more certain is the classification, so the complement is the uncertainty
            classif_uncertainty = torch.tensor(
                [1-score for score in images["scores"]]
            )
            # entropy for one image is the max of the entropies of the detections
            batch_scores[i] = classif_uncertainty.max()

    return batch_scores


class entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset: List, return_scores=False):
        """Select unlabaled items based on entpory scores

        Args:
            unlabeled_subset (List): _description_
            return_scores (bool, optional): _description_. Defaults to False.

        Returns:
            _type_: _description_
        """        

        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=self.config.batch_size,
            num_workers=self.config.workers,
            sampler=SequentialSampler(unlabeled_subset),
            collate_fn=maskrcnn_collate_fn,
            drop_last=True,
        )
        
        scores: np.ndarray = torch.zeros(len(unlabeled_subset)).cuda(0)
        d_model = self.model.cuda(0)
        d_model.eval()

        i = 0
        pbar = tqdm(unlab_loader, desc="Scoring unlabeled dataloader using Entropy")
        for ii,batchs in enumerate(pbar):
            imgs, target = d_model.prepare_batch(batchs)
            bs = len(imgs)
            imgs = [img.cuda(0) for img in imgs]
            outputs = d_model.forward_proba(imgs)

            scores[i : i + bs] = entropy_od(outputs)
            assert torch.isnan(scores).sum() == 0, f"{torch.isnan(scores).sum().sum()=}"
            if (ii%self.save_freq == 0) or (ii == len(pbar)-1):
                torch.save(scores, self.config.log_dir + "/scores.pth")
                np.save(self.config.log_dir + "/names.npy", self.base_dataset_index[unlabeled_subset])
                np.save(self.config.log_dir + "/indices.npy", unlabeled_subset)

            pbar.set_postfix({"Mean Entropies": scores[: i + bs].mean().item()})
            i += bs

        self.logger.info(
            f"{scores.mean()=} {scores.std()=} {scores.min()=} {scores.max()=}"
        )

        selected = torch.topk(scores, self.budget).indices

        selected = unlabeled_subset[selected.cpu().numpy()]
        
        
        if return_scores:
            return selected, scores
        return selected


# ==================================================================================================
#                   Exploration Strategies
# ==================================================================================================


@dataclass
class deepcoresetSampling(baseStrat):
    @torch.no_grad()
    def compute_embeddings_instance(self, subset=None) -> np.ndarray:
        dataset = (
            self.base_dataset if subset is None else Subset(self.base_dataset, subset)
        )

        return compute_embeddings_instance(
            model=self.model,
            D=dataset,
            config=self.config,
            logger=self.logger,
            seed=self.config.seed,
            precomputed_features=self.precomputed_features,
        )

    @torch.no_grad()
    def select(self, unlabeled_subset):
        def euclidean_dist(x, y):
            return torch.cdist(x, y, p=2)

        def cosdist(v1, v2):
            # i took the code of a cosine similarity function and modified it to return cosine distance by taking the inverse
            num = torch.matmul(v1, v2.T)
            denom = torch.norm(v1, dim=1).view(-1, 1) * torch.norm(v2, dim=1)
            res = num / denom
            res[torch.isneginf(res)] = 0
            return 1 / (0.5 + 0.5 * res)

        matrix = self.compute_embeddings_instance(
            np.concatenate([self.labeled_indices, unlabeled_subset])
        )
        if self.budget is None:
            self.budget = len(unlabeled_subset)
        selected, distances = k_center_greedy(
            matrix=matrix,
            budget=self.budget,
            metric=euclidean_dist,
            device="cuda:0",
            index=None,
            already_selected=np.arange(len(self.labeled_indices)),
        )

        self.logger.info(
            f"{distances.mean()=}  {distances.std()=} {distances.min()=} {distances.max()=} {(distances==-1).sum()=}"
        )
        # the k center greedy function return indices of selected individuals + the old labeled items.
        selected = np.concatenate([self.labeled_indices, unlabeled_subset])[selected]
        selected = np.setdiff1d(selected, self.labeled_indices)
        return selected


typiclustSampling: baseStrat = classif_functions["typiclustSampling"]


AVAILABLE_SCORING_FUNCTIONS = {
    # baseline
    "randomSampling": randomSampling,
    # exploitation
    "entropySampling": entropySampling,
    # exploration
    "deepcoresetSampling": deepcoresetSampling,
    "typiclustSampling": typiclustSampling,
}
