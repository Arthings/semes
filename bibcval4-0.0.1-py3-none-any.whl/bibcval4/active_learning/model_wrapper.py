import torch

class AL_maskrcnn(torch.nn.Module):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def forward_proba(self, x):
        return self(x)
    
    def forward_embedding(self, x):
        bs = len(x)
        images = torch.stack(x)
        return self.model.model.backbone(images)["pool"].view(bs, -1)
    
    @staticmethod
    def prepare_batch(batch):
        images, targets = batch
        return images, targets