from lightning import Callback
from lightning.pytorch.utilities import rank_zero_only
import os 
import pandas as pd 
import lightning as L
from torchvision.utils import make_grid

def make_file_name(config):
    reset = "RESET" if config.reset_model else "KEEP"
    fname = f"replication_metrics_{config.strat}_{reset}.csv"
    
    return fname


class ActiveLearningCallbacks(Callback):
    """Call back to add to trainer that will be used in active learning will be doing 2 things : 
        - logging metrics thgrout a tensorboard writeg along all AL cycles, since multiple training will happen one logger will gather all computations and keep it a the same place
        - Generate a csv file with all the validation metrics logged during validation_step

    Args:
        Callback (_type_): _description_
    """    
    def __init__(self, writer):
        self.writer = writer
    @rank_zero_only
    def on_train_epoch_end(self, trainer:L.Trainer, pl_module):
        global_step = pl_module.config.current_rep*pl_module.config.epochs*pl_module.config.cycles + pl_module.config.current_cycle*pl_module.config.epochs + pl_module.current_epoch
        optimizer= pl_module.optimizers()
        self.writer.add_scalar("Global/LR",optimizer.param_groups[0]['lr'], global_step)

        metrics = trainer.callback_metrics
        
        for keys, values in metrics.items():    
            self.writer.add_scalar(keys,values, global_step)
    
    @rank_zero_only
    def on_validation_epoch_end(self, trainer, pl_module):
        global_step = pl_module.config.current_rep*pl_module.config.epochs*pl_module.config.cycles + pl_module.config.current_cycle*pl_module.config.epochs + pl_module.current_epoch
        optimizer= pl_module.optimizers()
        self.writer.add_scalar("Global/LR",optimizer.param_groups[0]['lr'], global_step)

        # show images at each cycles of the first repetition.
        if pl_module.config.current_rep == 0:
            images, labels = pl_module.prepare_batch(next(iter(trainer.val_dataloaders)))
            if len(images) > 10:
                images = images[:10]
                labels = labels[:10]

            outputs = pl_module(images.to(pl_module.device))
            if  outputs.shape[1] != 1:
                outputs = outputs.argmax(1, keepdim = True)


            self.writer.add_image('images', make_grid(images), pl_module.config.current_cycle)
            self.writer.add_image('masks', make_grid(labels.unsqueeze(1)), pl_module.config.current_cycle)
            self.writer.add_image('preds', make_grid(outputs).sigmoid(), pl_module.config.current_cycle)

        if trainer.train_dataloader is None:
            # we log to csv file only on the validate that is done after the training.
            # we check it if there is no training dataloader in the trainer.
            pass