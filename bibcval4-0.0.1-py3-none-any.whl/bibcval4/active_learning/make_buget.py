import numpy as np
import math 

def isiterable(obj):
    try:
        iter(obj)
    except TypeError:
        return False
    return True


def make_budget(config, al_dataset, logger):
    """Create a budjets list given a budget argument of a config

    Args:
        config (_type_): _description_
        al_dataset (_type_): _description_
        logger (_type_): _description_

    Raises:
        ValueError: _description_

    Returns:
        _type_: _description_

    We can create 3 types of budget;
         int given an int and a number of cycles -> The budget will be the int repeated cycle times
         List[float]: Will budget percentages of the total dataset
         List[int]: the number of images to add at each cycle. 

    """    
    if type(config.budget) is int:
        # if you provide budget as an integer, the AL procudeure will consier <cycles> labeling cycles adding
        budgets = [config.budget for _ in range(config.cycles)]

    elif isiterable(config.budget) and type(config.budget[0]) is float:
        # here you provide proportion of full dataset to be labeled at each cycle
        cycles = len(config.budget)
        if logger is not None:
            logger.info(
                f"Ignoring cycles provided in config file ({config.cycles}) and running {cycles} cycles according to len of provided budget"
            )
        budgets_cum = np.array([int(prop * len(al_dataset)) for prop in config.budget])
        budgets = budgets_cum.copy()
        for i in range(1, cycles):
            budgets[i] = budgets_cum[i] - budgets_cum[i - 1]
        for i in range(cycles):
            # we check wether computed budgets correspond to the provided proportions
            assert math.isclose(
                np.cumsum(budgets)[i] / len(al_dataset), config.budget[i], abs_tol=0.1
            ), (
                f"budgets {np.cumsum(budgets)[i] / len(al_dataset)} is not equal to {config.budget[i]}"
            )
        if logger is not None:
            logger.info(f"Budget for this experiment is going to be : {budgets}")
    elif isiterable(config.budget) and type(config.budget[0]) is int:
        cycles = len(config.budget)
        if logger is not None:
            logger.info(
                f"Ignoring cycles provided in config file ({config.cycles}) and running {cycles} cycles according to len of provided budget"
            )
        budgets = config.budget
    else:
        raise ValueError(
            f"budget must be an int, a list of int or a list of float {print(type(config.budget))}"
        )
    
    assert sum(budgets) <= len(al_dataset), "Total number of selected items is bigger than the size of the dataset"
    return budgets