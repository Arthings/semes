from torch.utils.data import DataLoader, Dataset, SubsetRandomSampler, SequentialSampler

from typing import Callable, Tuple, List

import numpy as np
from ..base import baseStrat
import torch
import gc
import lightning as L
import pandas as pd
import os
from time import time
from ..utils import test_strat
from .make_buget import make_budget
from ..utils import check_proc
from .ActiveLearningDataset import ActiveLearningDataset
import math


def isiterable(obj):
    try:
        iter(obj)
    except TypeError:
        return False
    return True


def make_file_name(config):
    reset = "RESET" if config.reset_model else "KEEP"
    fname = f"replication_metrics_{config.strat}_{reset}.csv"
    return fname


def label_selected(
    dl: np.ndarray, du: np.ndarray, s: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """return a copy of Dl and Du after removing s from Du and adding them to Dl

    Args:
        dl (np.ndarray): indices of labeled items
        du (np.ndarray): indices of unlabeled items
        s (np.ndarray): items of Du to be moved to Dl

    Returns:
        Tuple[np.ndarray, np.ndarray]: updated (Dl and Du)
    """
    dl = np.copy(dl)
    du = np.copy(du)

    assert np.isin(dl, s).sum() == 0, (
        f"{np.isin(dl, s).sum()} selected items are already in the labeled dataset"
    )
    assert np.isin(du, dl).sum() == 0, "items are both labeled and unlabeled"

    dl = np.concatenate([dl, s])
    du = np.setdiff1d(du, s)
    return dl, du


def al_loop(
    config,
    dataset: Dataset,
    dataset_index: List[str],
    val_loader: DataLoader,
    strategy: baseStrat,
    get_trainer: Callable,
    create_module: Callable,
    logger,
    writer,
    precomputed_features: str = None,
    start_random=True,
):
    """_summary_

    Args:
        config (_type_): Dictconfig with all hyperparameter
        dataset (Dataset): Dataset used as starting Du
        val_loader (DataLoader): Validation dataloader used to validate along each AL cycle
        strategy (baseStrat): Al strategy
        get_trainer (Callable): function that take no input and return a new trainer
        create_module (Callable): function that take config as input and return a lightning module
        writer (_type_): tensorboard SummaryWriter that logs all metrics logged by the lightning module
        hook_process_func (_type_, optional): function that parse embeddings hooked at config.hook_layer Defaults to lambdax:x.squeeze().
        precomputed_features (str, optional): path to file containing pre-computed feature to run core-set selection algorithm. Defaults to None.
    """
    repetitions: int = config.repetitions
    cycles: int = config.cycles
    seed: int = config.seed
    subset: int = config.subset

    check_proc(dataset, config, precomputed_features, create_module(config))

    assert len(dataset) == len(dataset_index), (
        f"dataset and dataset_index must have the same length, here {len(dataset)=}, {len(dataset_index)=}"
    )

    al_dataset = ActiveLearningDataset(dataset, config, dataset_index)

    # setup budgets_list
    # at each cycle, budget should be the number of data ADDED to the current labeled set

    budgets = make_budget(config, al_dataset, logger)
    L.pytorch.seed_everything(seed, workers=True)

    torch.use_deterministic_algorithms(True, warn_only=True)

    # Log items selection along runs
    selection_path = os.path.join(config.log_dir, "items_selection")
    os.makedirs(selection_path, exist_ok=True)
    with open(
        os.path.join(
            selection_path, f"selected_items_{config.strat}_{config.reset_model}.csv"
        ),
        "w",
    ) as f:
        f.write("repetition;cycle;selected;strat;name\n")

    for repetition in range(repetitions):
        config.current_rep = repetition
        model = create_module(config)
        al_dataset.start_rep()

        t0_rep = time()
 
        for cycle in range(cycles):
            t0_cycle = time()
            config.current_cycle = cycle
            budget = budgets[cycle]

            model.config = config
            t1_score = time()

            strat_object = strategy(
                al_dataset,
                val_loader,
                model,
                config,
                logger,
                budget,
                cycles,
                precomputed_features,
            )

            # Random selection if first cycle.
            if cycle == 0 and start_random:     
                # first selection
                selected = np.random.choice(len(dataset), budget, replace=False)
                logger.info("FIRST CYCLE : RANDOM SELECTION")
                
            else:
                # cycle != 0
                # normal scoring on a subset
                selected = strat_object.select(al_dataset.unlabeled_subset)
                
            test_strat(
                al_dataset.labeled_indices,
                al_dataset.unlabeled_indices,
                selected,
                budget,
                cycle,
            )
            al_dataset.label(selected)
            # =========================================================
            #                       LOGGING
            # =========================================================
            # Logging items selected this cycle

            (
                pd.concat(
                    [
                        pd.read_csv(
                            os.path.join(
                                selection_path,
                                f"selected_items_{config.strat}_{config.reset_model}.csv",
                            ),
                            sep=";",
                            index_col=0,
                        ),
                        pd.DataFrame(
                            {
                                "repetition": repetition,
                                "cycle": cycle,
                                "selected": selected,
                                "strat": config.strat,
                                "name": dataset_index[selected],
                            },
                            index=np.arange(len(selected)),
                        ),
                    ]
                ).to_csv(
                    os.path.join(
                        selection_path,
                        f"selected_items_{config.strat}_{config.reset_model}.csv",
                    ),
                    sep=";",
                )
            )

            # =========================================================
            #  Training
            # =========================================================
            if config.reset_model and cycle != 0:
                model = create_module(config)
                model.config = config
                logger.info(
                    f"Model Weights have been erased to start cycle {cycle} from scratch"
                )
            labeled_loader = al_dataset.labeled_dataloader()

            t1_start_train = time()

            trainer: L.Trainer = get_trainer()

            trainer.fit(model, train_dataloaders=labeled_loader, val_dataloaders=val_loader)
            trainer.test(model, val_loader)



            # =========================================================
            #  LOGGING
            # =========================================================
            # index of the current epoch in the whole AL procedure
            global_step = (
                repetition * config.epochs * cycles
                + cycle * config.epochs
                + model.current_epoch
            )

            output_folder = os.path.join(model.config.log_dir, "replication_metrics")
            os.makedirs(output_folder, exist_ok=True)

            fname = make_file_name(config)
            metrics = trainer.logged_metrics

            for metric_name, metric_value in metrics.items():
                writer.add_scalar(metric_name, metric_value, global_step)

            training_dict = {
                "cycle": cycle,
                "repetition": repetition,
                "epoch": trainer.current_epoch,
                "labeled_items": len(al_dataset.labeled_indices),
            }

            m = {i: j.item() for i, j in metrics.items()}
            dict_to_log = {**m, **training_dict}

            log_dfpath = os.path.join(output_folder, fname)

            if (cycle == 0) and (repetition == 0):
                df = pd.DataFrame(dict_to_log, index=[0])
                df.to_csv(log_dfpath, sep=";")
            else:
                saved_df = pd.read_csv(log_dfpath, sep=";", index_col=0)
                current_df = pd.DataFrame(dict_to_log, index=[0])

                updated_df = pd.concat([saved_df, current_df])
                updated_df.to_csv(log_dfpath, sep=";")

            t2_end_train = time()

            logger.info(f"""
            Cycle {cycle + 1}/{cycles} ended. rep {repetition + 1} / {repetitions}
            {(t2_end_train - t0_cycle) / 60:.4f} minutes for the cycle
            {(t1_start_train - t1_score) / 60:4f} for scoring
            {(t2_end_train - t1_start_train) / 60:.4f} for training + val 
            {(t1_start_train - t1_score) / 60:4f} for scoring 
            {(t2_end_train - t1_start_train) / 60:.4f} for training + val
            {len(al_dataset.labeled_indices)=} {budget=} {round(len(al_dataset.labeled_indices)/len(al_dataset), 3)=}
            {len(al_dataset.unlabeled_indices)=}, {len(al_dataset)=}
            {subset=}
            """)

        # clear memory because of a cuda OOM error
        del model
        a = gc.collect()
        print(a)
        torch.cuda.empty_cache()
        logger.info(f"""
        Repetition : {repetition + 1} ended
        {(time() - t0_rep) / 60:.4f} minutes taken
        estimated time for full AL procedure {repetitions * (time() - t0_rep) / 60:.4f} minutes
        estimated time for full AL procedure {repetitions * (time() - t0_rep) / 60 / 60:.4f} hours
        """)


def al_loop_bibcv(
    config,
    dataset: Dataset,
    dataset_index: List[str],
    val_loader: DataLoader,
    strategy: baseStrat,
    trainer,
    model,
    logger,
    writer,
    precomputed_features: str = None,
    start_random=True,
):
    """_summary_

    Args:
        config (_type_): Dictconfig with all hyperparameter
        dataset (Dataset): Dataset used as starting Du
        val_loader (DataLoader): Validation dataloader used to validate along each AL cycle
        strategy (baseStrat): Al strategy
        get_trainer (Callable): function that take no input and return a new trainer
        create_module (Callable): function that take config as input and return a lightning module
        writer (_type_): tensorboard SummaryWriter that logs all metrics logged by the lightning module
        hook_process_func (_type_, optional): function that parse embeddings hooked at config.hook_layer Defaults to lambdax:x.squeeze().
        precomputed_features (str, optional): path to file containing pre-computed feature to run core-set selection algorithm. Defaults to None.
    """
    repetitions: int = config.repetitions
    cycles: int = config.cycles
    subset: int = config.subset

    logger.info(
        f"function start{torch.cuda.memory_allocated(0)/1024**2} MB of GPU memory allocated \n \
        {torch.cuda.get_device_properties(0).total_memory/1024**2} MB of GPU memory available"
    )
    
    initial_state_dict = model.state_dict()


    check_proc(dataset, config, precomputed_features, model)
    assert len(dataset) == len(dataset_index), (
        f"dataset and dataset_index must have the same length, here {len(dataset)=}, {len(dataset_index)=}"
    )

    al_dataset = ActiveLearningDataset(dataset, config, dataset_index)

    # setup budgets_list
    # at each cycle, budget should be the number of data ADDED to the current labeled set

    if type(config.budget) is int:
        # if you provide budget as an integer, the AL procudeure will consier <cycles> labeling cycles adding
        budgets = [config.budget for _ in range(cycles)]

    elif isiterable(config.budget) and type(config.budget[0]) is float:
        # here you provide proportion of full dataset to be labeled at each cycle
        cycles = len(config.budget)
        logger.info(
            f"Ignoring cycles provided in config file ({config.cycles}) and running {cycles} cycles according to len of provided budget"
        )
        budgets_cum = np.array([int(prop * len(al_dataset)) for prop in config.budget])
        budgets = budgets_cum.copy()
        for i in range(1, cycles):
            budgets[i] = budgets_cum[i] - budgets_cum[i - 1]
        for i in range(cycles):
            # we check wether computed budgets correspond to the provided proportions
            assert math.isclose(
                np.cumsum(budgets)[i] / len(al_dataset), config.budget[i], abs_tol=0.1
            ), (
                f"budgets {np.cumsum(budgets)[i] / len(al_dataset)} is not equal to {config.budget[i]}"
            )
        logger.info(f"Budget for this experiment is going to be : {budgets}")
    elif isiterable(config.budget) and type(config.budget[0]) is int:
        cycles = len(config.budget)
        logger.info(
            f"Ignoring cycles provided in config file ({config.cycles}) and running {cycles} cycles according to len of provided budget"
        )
        budgets = config.budget
    else:
        raise ValueError(
            f"budget must be an int, a list of int or a list of float {print(type(config.budget))}"
        )
    logger.info(f"Budget for this experiment is going to be : {budgets}")

    torch.use_deterministic_algorithms(True, warn_only=True)

    # Log items selection along runs
    selection_path = os.path.join(config.log_dir, "items_selection")
    os.makedirs(selection_path, exist_ok=True)
    with open(
        os.path.join(
            selection_path, f"selected_items_{config.strat}_{config.reset_model}.csv"
        ),
        "w",
    ) as f:
        f.write("repetition;cycle;selected;strat;name\n")
  

    for repetition in range(repetitions):
        config.current_rep = repetition

        al_dataset.start_rep()

        t0_rep = time()

        for cycle in range(cycles):
            t0_cycle = time()
            config.current_cycle = cycle
            budget = budgets[cycle]

            if config.reset_model and cycle != 0:
                model = model.load_state_dict(initial_state_dict)
                trainer.model = model

                logger.info(
                    f"Model Weights have been erased to start cycle {cycle} from scratch"
                )
            t1_score = time()

            strat_object = strategy(
                dataset,
                val_loader,
                model,
                config,
                logger,
                budget,
                cycles,
                precomputed_features,
            )

            # Random selection if first cycle.
            if cycle == 0 and start_random:
                # first selection
                selected = np.random.choice(len(dataset), budget, replace=False)

            else:

                # cycle != 0
                # normal scoring on a subset
                selected = strat_object.select(al_dataset.unlabeled_subset)

            test_strat(
                al_dataset.labeled_indices,
                al_dataset.unlabeled_indices,
                selected,
                budget,
                cycle,
            )

            al_dataset.label(selected)
            del strat_object
            
            # =========================================================
            #                       LOGGING
            # =========================================================
            # Logging items selected this cycle

            (
                pd.concat(
                    [
                        pd.read_csv(
                            os.path.join(
                                selection_path,
                                f"selected_items_{config.strat}_{config.reset_model}.csv",
                            ),
                            sep=";",
                            index_col=0,
                        ),
                        pd.DataFrame(
                            {
                                "repetition": repetition,
                                "cycle": cycle,
                                "selected": selected,
                                "strat": config.strat,
                                "name": dataset_index[selected],
                            },
                            index=np.arange(len(selected)),
                        ),
                    ]
                ).to_csv(
                    os.path.join(
                        selection_path,
                        f"selected_items_{config.strat}_{config.reset_model}.csv",
                    ),
                    sep=";",
                )
            )

            # =========================================================
            #  Training
            # =========================================================
            labeled_loader = al_dataset.labeled_dataloader()
            print(labeled_loader.batch_size)

            t1_start_train = time()
            
            logger.info(
                f"Before fit: {torch.cuda.memory_allocated(0)/1024**2} MB of GPU memory allocated \n \
                {torch.cuda.get_device_properties(0).total_memory/1024**2} MB of GPU memory available"
            )

            trainer.fit(train_dataloader=labeled_loader, val_dataloader=val_loader)

            # =========================================================
            #  LOGGING
            # =========================================================
            # index of the current epoch in the whole AL procedure
            global_step = (
                repetition * config.epochs * cycles
                + cycle * config.epochs
                + config.current_epoch
            )

            output_folder = os.path.join(config.log_dir, "replication_metrics")
            os.makedirs(output_folder, exist_ok=True)

            fname = make_file_name(config)
            metrics = trainer.val_logged_metrics

            for metric_name, metric_value in metrics.items():
                writer.add_scalar(metric_name, metric_value, global_step)

            training_dict = {
                "cycle": cycle,
                "repetition": repetition,
                "epoch": trainer.current_epoch,
                "labeled_items": len(al_dataset.labeled_indices),
            }

            m = {i: j.item() for i, j in metrics.items()}
            dict_to_log = {**m, **training_dict}

            log_dfpath = os.path.join(output_folder, fname)

            if (cycle == 0) and (repetition == 0):
                df = pd.DataFrame(dict_to_log, index=[0])
                df.to_csv(log_dfpath, sep=";")
            else:
                saved_df = pd.read_csv(log_dfpath, sep=";", index_col=0)
                current_df = pd.DataFrame(dict_to_log, index=[0])

                updated_df = pd.concat([saved_df, current_df])
                updated_df.to_csv(log_dfpath, sep=";")

            t2_end_train = time()

            logger.info(f"""
            Cycle {cycle + 1}/{cycles} ended. rep {repetition + 1} / {repetitions}
            {(t2_end_train - t0_cycle) / 60:.4f} minutes for the cycle
            {(t1_start_train - t1_score) / 60:4f} for scoring
            {(t2_end_train - t1_start_train) / 60:.4f} for training + val 
            {(t1_start_train - t1_score) / 60:4f} for scoring 
            {(t2_end_train - t1_start_train) / 60:.4f} for training + val
            {len(al_dataset.labeled_indices)=} {budget=} {round(len(al_dataset.labeled_indices)/len(al_dataset), 3)=}
            {len(al_dataset.unlabeled_indices)=}, {len(al_dataset)=}
            {subset=}
            """)

        # clear memory because of a cuda OOM error
        a = gc.collect()
        print(a)
        torch.cuda.empty_cache()
        logger.info(f"""
        Repetition : {repetition + 1} ended
        {(time() - t0_rep) / 60:.4f} minutes taken
        estimated time for full AL procedure {repetitions * (time() - t0_rep) / 60:.4f} minutes
        estimated time for full AL procedure {repetitions * (time() - t0_rep) / 60 / 60:.4f} hours
        """)


def al_loop_feed_val(
    config,
    dataset: Dataset,
    strategy: baseStrat,
    get_trainer: Callable,
    create_module: Callable,
    logger,
    writer,
    hook_process_func: Callable = lambda x: x.squeeze(),
    precomputed_features: str = None,
    PATATE_TEST: bool = False,
):
    """_summary_

    Args:
        config (_type_): Dictconfig with all hyperparameter
        dataset (Dataset): Dataset used as starting Du
        strategy (baseStrat): Al strategy
        get_trainer (Callable): function that take no input and return a new trainer
        create_module (Callable): function that take config as input and return a lightning module
        writer (_type_): tensorboard SummaryWriter that logs all metrics logged by the lightning module
        hook_process_func (_type_, optional): function that parse embeddings hooked at config.hook_layer Defaults to lambdax:x.squeeze().
        precomputed_features (str, optional): path to file containing pre-computed feature to run core-set selection algorithm. Defaults to None.
        PATATE_TEST (bool, optional): Should not be used, prototype for the patate project. Defaults to False.
    """
    repetitions: int = config.repetitions
    seed: int = config.seed
    subset: int = config.subset
    batch_size: int = config.batch_size

    check_proc(dataset, config, precomputed_features, create_module(config))

    config.train_step = 0
    config.valid_step = 0

    L.pytorch.seed_everything(seed, workers=True)

    # we preselect items to be randomly selected on the first cycle of each repetition.
    if PATATE_TEST:
        # Only WORK WITH the POTATO PROJECT WITH SUBSETS
        # it means we will only select faulty items whatever the bias is for the first cycle
        dataset: torch.utils.data.Subset
        defect_indices = torch.where(
            torch.from_numpy(dataset.dataset.labels[dataset.indices]) == 1
        )[0]
        first_labeled = [
            np.random.choice(defect_indices, config.budget, replace=False)
            for _ in range(repetitions)
        ]
    else:
        first_labeled = [
            torch.randperm(len(dataset))[: config.budget].numpy()
            for _ in range(repetitions)
        ]

    torch.use_deterministic_algorithms(True)  # , warn_only=True)

    # Log items selection along runs
    selection_path = os.path.join(config.log_dir, "items_selection")
    os.makedirs(selection_path, exist_ok=True)
    with open(
        os.path.join(
            selection_path, f"selected_items_{config.strat}_{config.reset_model}.csv"
        ),
        "w",
    ) as f:
        f.write("repetition;cycle;selected;strat;name\n")

    for repetition in range(repetitions):
        config.current_rep = repetition
        model = create_module(config)

        t0_rep = time()
        training_indices = np.array([]).astype(int)
        validation_indices = np.array([]).astype(int)
        val_loader = None

        unlabeled_indices = np.arange(len(dataset)).astype(int)

        for cycle in range(config.cycles):
            t0_cycle = time()
            config.current_cycle = cycle
            model.config = config

            if config.reset_model and cycle != 0:
                model = create_module(config)
                logger.info(
                    f"Model Weights have been erased to start cycle {cycle} from scratch"
                )

            t1_score = time()

            strat_object = strategy(
                dataset,
                training_indices,
                unlabeled_indices,
                val_loader,
                model,
                config,
                logger,
                hook_process_func,
                precomputed_features,
            )

            # Random selection if first cycle.
            if cycle == 0:
                # first selection
                selected = first_labeled[repetition]

            else:
                # cycle != 0
                # normal scoring on a subset
                model.configure_model()
                unlabeled_subset = select_subset(unlabeled_indices, subset)

                selected = strat_object.select(unlabeled_subset)

            test_strat(
                np.concatenate([validation_indices, training_indices]),
                unlabeled_indices,
                selected,
                config.budget,
                cycle,
            )

            # we add 80% of selected data  to training indices
            selected_training = np.random.choice(
                selected, int(0.8 * config.budget), replace=False
            )

            # the remaining is added to validation
            selected_validation = np.setdiff1d(selected, selected_training)

            training_indices, unlabeled_indices = label_selected(
                training_indices, unlabeled_indices, selected_training
            )

            validation_indices, unlabeled_indices = label_selected(
                validation_indices, unlabeled_indices, selected_validation
            )

            # =========================================================
            #                       LOGGING
            # =========================================================
            # Logging items selected this cycle
            (
                pd.concat(
                    [
                        pd.read_csv(
                            os.path.join(
                                selection_path,
                                f"selected_items_{config.strat}_{config.reset_model}.csv",
                            ),
                            sep=";",
                            index_col=0,
                        ),
                        pd.DataFrame(
                            {
                                "repetition": repetition,
                                "cycle": cycle,
                                "selected": selected,
                                "strat": config.strat,
                                "name": [dataset[i]["name"] for i in selected],
                            },
                            index=np.arange(len(selected)),
                        ),
                    ]
                ).to_csv(
                    os.path.join(
                        selection_path,
                        f"selected_items_{config.strat}_{config.reset_model}.csv",
                    ),
                    sep=";",
                )
            )

            # =========================================================
            labeled_loader = DataLoader(
                dataset,
                batch_size=batch_size,
                num_workers=config.workers,
                sampler=SubsetRandomSampler(training_indices),
                pin_memory=True,
            )
            val_loader = DataLoader(
                dataset,
                batch_size=batch_size,
                num_workers=config.workers,
                sampler=SequentialSampler(validation_indices),
                pin_memory=True,
            )

            t1_start_train = time()

            trainer: L.Trainer = get_trainer()

            trainer.fit(
                model, train_dataloaders=labeled_loader, val_dataloaders=val_loader
            )
            trainer.validate(model, dataloaders=val_loader)[0]
            global_step = (
                model.config.current_rep * model.config.epochs * model.config.cycles
                + model.config.current_cycle * model.config.epochs
                + model.current_epoch
            )

            output_folder = os.path.join(model.config.log_dir, "replication_metrics")
            os.makedirs(output_folder, exist_ok=True)

            fname = make_file_name(config)

            metrics = trainer.callback_metrics

            for metric_name, metric_value in metrics.items():
                writer.add_scalar(metric_name, metric_value, global_step)

            training_dict = {
                "cycle": cycle,
                "repetition": repetition,
                "epoch": trainer.current_epoch,
                "labeled_items": (cycle + 1) * config.budget,
            }

            m = {i: j.item() for i, j in metrics.items()}
            dict_to_log = {**m, **training_dict}

            log_dfpath = os.path.join(output_folder, fname)

            if (cycle == 0) and (repetition == 0):
                df = pd.DataFrame(dict_to_log, index=[0])
                df.to_csv(log_dfpath, sep=";")
            else:
                saved_df = pd.read_csv(log_dfpath, sep=";", index_col=0)
                current_df = pd.DataFrame(dict_to_log, index=[0])

                updated_df = pd.concat([saved_df, current_df])
                updated_df.to_csv(log_dfpath, sep=";")

            t2_end_train = time()

            logger.info(f"""
            Cycle {cycle + 1}/{config.cycles} ended. rep {repetition + 1} / {repetitions}
            {(t2_end_train - t0_cycle) / 60:.4f} minutes for the cycle
            {(t1_start_train - t1_score) / 60:4f} for scoring
            {(t2_end_train - t1_start_train) / 60:.4f} for training + val 
            {(t1_start_train - t1_score) / 60 / len(unlabeled_indices):4f} for scoring per image
            {(t2_end_train - t1_start_train) / 60 / len(training_indices):.4f} for training + val per image  
            {len(training_indices)=} {len(validation_indices)=} {config.budget=}
            {len(unlabeled_indices)=}, {len(dataset)=}
            {subset=}
            """)

        # clear memory because of a cuda OOM error
        del model
        a = gc.collect()
        print(a)
        torch.cuda.empty_cache()
        logger.info(f"""
        Repetition : {repetition + 1} ended
        {(time() - t0_rep) / 60:.4f} minutes taken
        estimated time for full AL procedure {repetitions * (time() - t0_rep) / 60:.4f} minutes
        estimated time for full AL procedure {repetitions * (time() - t0_rep) / 60 / 60:.4f} hours
        """)
