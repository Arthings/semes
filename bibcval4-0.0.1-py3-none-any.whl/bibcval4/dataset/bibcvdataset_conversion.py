import copy
from torch.utils.data import DataLoader
import pandas as pd
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from bibcvdatasets.imagedataset import ImageDataset

"""
Abstract method used to make external datasets act like bibcvdatasets.

The children classes should inherit from it and from any sort of torch Dataset.
It should implement following attributes :

"""

@dataclass
class Semibibcv(ABC):

    def __post_init__(self):
        self._dataframe = field(default = None)

    @abstractmethod
    def set_dataframe(self):
        pass

    @property
    def dataframe(self)->pd.DataFrame:
        return self._dataframe

    @dataframe.setter
    def dataframe(self, value: pd.DataFrame):
        assert isinstance(value, pd.DataFrame)
        self._dataframe = value.sort_index()
        
    def dataloader(self, batch_size:int, shuffle=True, num_workers = 0, sampler = None):
        return DataLoader(self, batch_size=batch_size, num_workers = num_workers, shuffle=shuffle, collate_fn=None, sampler= sampler)

    def __sub__(self, other: ImageDataset) -> ImageDataset:
        """Return a deepcopy of the dataset with only data that are not in other.

        Args:
            other (BaseDataset): _description_
        """
        result = copy.deepcopy(self)
        result._dataframe = result._dataframe.loc[
            ~result._dataframe.index.isin(other._dataframe.index)
        ]

        return result

    def __add__(self, other: ImageDataset) -> ImageDataset:
        """Return a deepcopy of the dataset containing data of both datasets.

        Args:
            other (BaseDataset): _description_

        Returns:
            BaseDataset: _description_

        """
        # We then verify that we don't have duplicated index
        self_in_other = self.dataframe.index.isin(other._dataframe.index).sum()
        other_in_self = other._dataframe.index.isin(self.dataframe.index).sum()
        assert (
            not self_in_other
        ), f"No index from first dataset should be in second dataset. {self_in_other}"
        assert (
            not other_in_self
        ), f"No index from second dataset should be in first dataset. {other_in_self}"

        result = copy.deepcopy(self)
        df = pd.concat([result._dataframe, other._dataframe])
        result._dataframe = df.copy()
        # We add the classes that we don't have in the end.
        for cls in other.clsNames:
            if cls not in result.clsNames:
                # We add at the end...
                result.clsNames[cls] = len(result.clsNames)
        return result
