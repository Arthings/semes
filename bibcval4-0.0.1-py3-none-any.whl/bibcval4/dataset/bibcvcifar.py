import torchvision
import albumentations as A
from albumentations.pytorch import ToTensorV2
from dataclasses import dataclass, field
import pandas as pd
import numpy as np
from typing import Union, List, Tuple, Callable
from .bibcvdataset_conversion import Semibibcv
import matplotlib.pyplot as plt

@dataclass
class bibcvcifar(Semibibcv, torchvision.datasets.CIFAR10 ):
    
    def __init__(self, *args, exclude_list=[], **kwargs):
        # super(bibcvcifar, self).__init__(*args, **kwargs)
        # the only constructor argument are coming to fill the cifar10 attributes. Semibibcv only provides methods.
        torchvision.datasets.CIFAR10.__init__(self, *args, **kwargs)
        self.clsNames = {
            0: 'airplane',
            1: 'automobile',
            2: 'bird',
            3: 'cat',
            4: 'deer',
            5: 'dog',
            6: 'frog',
            7: 'horse',
            8: 'ship',
            9: 'truck'
        }
        self._transform:Callable = field(init=False, default=None)
        self._dataframe = field(default = None)
        self.set_dataframe()
        self.clsNames = {v:k for k,v in self.clsNames.items()}

    
    def set_dataframe(self):
        self._dataframe = pd.DataFrame({
            "annotations" : [self.clsNames[i] for i in self.targets],
            "image_id":np.arange(super().__len__())
        },
         index = np.arange(super().__len__()))

    def __getitem__(self, idx: int):
        assert idx <= self.dataframe.shape[0], f"idx {idx} requested is out of bounds ({self.dataframe.shape[0]})"

        image_id = self.dataframe.reset_index().iloc[idx,0]

        image, category = super().__getitem__(image_id)

        seg_item = {
            "image" : np.array(image),
            "cls_id" : category,
            "name" : self.dataframe.image_id.iloc[idx]
        }

        return self._transform(seg_item)

    def __len__(self):
        return self._dataframe.shape[0]
    
    def show_image(self, idx):
        seg_item = self[idx]
        a={v:k for k,v in self.clsNames.items()}
        fig, ax = plt.subplots()
        plt.title(f"{a[seg_item['cls_id']]}")
        ax.set(xticklabels=[], yticklabels=[], xticks=[], yticks=[])
        ax.imshow(seg_item['image'].permute(1,2,0))

        

def iris2_classif(segmentation_item:dict):
    transform = A.Compose([
        # A.Resize(128,128),
        A.ToFloat(max_value=255),
        ToTensorV2()
    ])
    output = transform(
        image = segmentation_item['image'])
    output['name'] = segmentation_item['name']
    output["cls_id"] = segmentation_item["cls_id"]
    return output



if __name__ == "__main__":
    pass