import torch
from torch.utils.data import DataLoader

# from bibcval3.classification import Trainer
import numpy as np
from ..utils import SubsetLinearSampler
from ..base import baseStrat
from tqdm.auto import tqdm

# from scipy.stats import entropy
from ..base.CoreSet import k_center_greedy, greedy_k_center
from dataclasses import dataclass


class randomSampling(baseStrat):
    def select(self, unlabeled_subset):
        selected = np.random.choice(unlabeled_subset, self.budget, replace=False)
        return selected.astype(int)


class entropySampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        bs = self.config.batch_size

        unlab_loader = DataLoader(
            self.base_dataset,
            batch_size=bs,
            num_workers=self.config.workers,
            sampler=SubsetLinearSampler(unlabeled_subset),
        )

        scores = np.zeros(len(unlabeled_subset))

        d_model = self.model.cuda(0)

        i = 0
        for batchs in tqdm(
            unlab_loader, desc="Scoring unlabeled dataloader using Entropy"
        ):
            imgs, _ = self.model.prepare_batch(batchs)
            imgs = imgs.cuda(0)
            assert torch.isnan(imgs).sum().item() == 0, (
                f"{torch.isnan(imgs).sum().item()=} nan values in input images"
            )

            outputs = d_model(imgs)

            assert torch.isnan(outputs).sum().item() == 0, (
                f"{torch.isnan(outputs).sum().item()=} nan values in model prediction"
            )

            t = torch.nn.functional.softmax(outputs, dim=-1)
            temp_scores = torch.special.entr(t).sum(-1).detach().cpu().numpy()

            scores[i : i + bs] = temp_scores

            i += bs

        # selected are items from unlabeled subset with highest scores
        selected = unlabeled_subset[
            torch.topk(torch.from_numpy(scores), self.budget).indices
        ]
        return selected


def margin_sampling():
    raise NotImplementedError("Margin Sampling is not implemented yet")


class deepcoresetSampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        def euclidean_dist(x, y):
            return torch.cdist(x, y, p=2)

        def cosdist(v1, v2):
            # i took the code of a cosine similarity function and modified it to return cosine distance by taking the inverse
            num = torch.matmul(v1, v2.T)
            denom = torch.norm(v1, dim=1).view(-1, 1) * torch.norm(v2, dim=1)
            res = num / denom
            res[torch.isneginf(res)] = 0
            return 1 / (0.5 + 0.5 * res)

        matrix = self.compute_embeddings_on_subset()
        
        # coreset deepcore
        # selected, distances  = k_center_greedy(
        #     matrix = matrix,
        #     budget = self.budget,
        #     metric = euclidean_dist,
        #     device = "cuda:0",
        #     index = None,
        #     already_selected=self.labeled_indices,
        # )
        # coreset typiclust
        selected, distances = greedy_k_center(
            matrix[self.labeled_indices, :],
            matrix[unlabeled_subset, :],
            budget=self.budget,
        )

        self.logger.info(
            f"{distances.mean()=}  {distances.std()=} {distances.min()=} {distances.max()=} {(distances==-1).sum()=}"
        )

        # the k center greedy function return indices of selected individuals + the old labeled items.
        # selected = np.concatenate([self.labeled_indices, unlabeled_subset])[selected]
        # selected = np.setdiff1d(selected, self.labeled_indices)

        selected = unlabeled_subset[selected]

        return selected

class typiclustSampling(baseStrat):
    @torch.no_grad()
    def select(self, unlabeled_subset):
        from .typiclust import TypiClust

        matrix = self.compute_embeddings_on_subset()

        typiclust_object = TypiClust(
            cfg=self.config,
            lSet=self.labeled_indices,
            uSet=unlabeled_subset,
            budgetSize=self.budget,
            features_matrix=matrix,
        )

        selected, scores = typiclust_object.select_samples()
        self.logger.info(
            f"{scores.mean()=}  {scores.std()=} {scores.min()=} {scores.max()=}"
        )

        return selected

def typiclust_coreset_sampling():
    raise NotImplementedError("Typiclust coreset Sampling is not implemented yet")


def tcm_sampling():
    raise NotImplementedError("TCM Sampling is not implemented yet")


AVAILABLE_SCORING_FUNCTIONS = {
    # baseline
    "randomSampling": randomSampling,
    # exploitation
    "entropySampling": entropySampling,
    # "margin_sampling": margin_sampling,
    # # exploration
    # "coreset_sampling": coreset_sampling,
    "deepcoresetSampling": deepcoresetSampling,
    "typiclustSampling": typiclustSampling,
    # "typiclust_coreset_sampling": typiclust_coreset_sampling,
    # # hybrid
    # "tcm_sampling": tcm_sampling,
}
