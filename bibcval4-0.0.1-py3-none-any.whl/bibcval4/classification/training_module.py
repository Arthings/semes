import torchvision
import torch
import torchmetrics
import lightning as L
from typing import List, Optional


class ClassifModel(L.LightningModule):
    def __init__(
        self,
        config,
        num_classes: int,
        model=None,
        class_names: Optional[List[str]] = None,
    ):
        # writer is a global logger that will log throught all the cycles ans repetitions
        super().__init__()

        if model is None:
            self.model = torchvision.models.resnet18(num_classes=num_classes)
        else:
            self.model = model

        self.criterion = torch.nn.CrossEntropyLoss()

        if class_names is None:
            self.class_names = [str(i) for i in range(num_classes)]
        else:
            self.class_names = class_names

        metric = torchmetrics.MetricCollection(
            (
                torchmetrics.F1Score(task="multiclass", num_classes=num_classes),
                torchmetrics.Accuracy(task="multiclass", num_classes=num_classes),
                torchmetrics.Precision(task="multiclass", num_classes=num_classes),
                torchmetrics.Recall(task="multiclass", num_classes=num_classes),
            )
        )

        self.train_metrics = metric.clone(prefix="Train/")
        self.val_metrics = metric.clone(prefix="Validation/")
        self.test_metrics = metric.clone(prefix="Test/")

        self.config = config

        self.percat_metrics = torchmetrics.MetricCollection(
            torchmetrics.F1Score(
                task="multiclass", num_classes=num_classes, average=None
            ),
            torchmetrics.Accuracy(
                task="multiclass", num_classes=num_classes, average=None
            ),
            torchmetrics.Precision(
                task="multiclass", num_classes=num_classes, average=None
            ),
            torchmetrics.Recall(
                task="multiclass", num_classes=num_classes, average=None
            ),
        )

    @staticmethod
    def prepare_batch(batch):
        return batch["image"], batch["label"]

    def forward(self, x):
        return self.model(x)

    def forward_proba(self, x):
        return self.model(x).softmax(1)

    def forward_predict(self, x):
        return self.model(x).argmax(1)

    def training_step(self, batch, batch_id):
        image, label = self.prepare_batch(batch)

        output = self(image)
        pred = output.argmax(1)
        
        loss = self.criterion(output, label.squeeze())
        self.log("Train/loss", loss, on_epoch=True, prog_bar=True)

        self.train_metrics(pred, label.squeeze())

        return loss

    def on_train_epoch_end(self):
        self.log_dict(self.train_metrics, on_epoch=True, sync_dist=True)

        self.train_metrics.reset()
        return

    def validation_step(self, batch, batch_id):
        image, label = self.prepare_batch(batch)

        output = self(image)
        pred = output.argmax(1)


        self.val_metrics(pred, label.squeeze())
        self.percat_metrics(pred, label.squeeze())

        self.log_dict(self.val_metrics, on_epoch=True)

        loss = self.criterion(output, label.squeeze())
        self.log("Validation/loss", loss, on_epoch=True)

        return

    def on_validation_epoch_end(self):
        self.log_dict(self.val_metrics, on_epoch=True, sync_dist=True)


        for metric_name, metric_object in self.percat_metrics.items():
            # we did not average the metrics over classes.
            # That is why we need to specifically log it
            for k, metric_value in enumerate(metric_object.compute()):
                self.log(
                    f"Validation/{metric_name} {self.class_names[k]}",
                    metric_value,
                    sync_dist=True,
                    batch_size=self.config.batch_size,
                )
        self.val_metrics.reset()
        self.percat_metrics.reset()
        return

    def test_step(self, batch, batch_id):
        image, label = self.prepare_batch(batch)

        output = self(image)
        pred = output.argmax(1)

        self.test_metrics(pred, label.squeeze())
        self.percat_metrics(pred, label.squeeze())

        loss = self.criterion(output, label.squeeze())
        self.log("Test/loss", loss, on_epoch=True)

        return

    def on_test_epoch_end(self):
        self.log_dict(self.test_metrics, on_epoch=True, sync_dist=True)

        for metric_name, metric_object in self.percat_metrics.items():
            # we did not average the metrics over classes.
            # That is why we need to specifically log it
            for k, metric_value in enumerate(metric_object.compute()):
                self.log(
                    f"Test/{metric_name} {self.class_names[k]}",
                    metric_value,
                    sync_dist=True,
                    batch_size=self.config.batch_size,
                )

        self.test_metrics.reset()
        self.percat_metrics.reset()
        return

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(
            self.parameters(), lr=self.config.lr
        )
        scheduler = torch.optim.lr_scheduler.StepLR(
            optimizer, step_size=1, gamma=0.1
        )

        return [optimizer], [scheduler]