from typing import Dict, Tuple, List
from torch import Tensor
import torch
from torchmetrics import Metric
import numpy as np

"""
Essai de rendre compatible le mascrcnn verdict de FP avec le distributed de torchmetrics pour une utilisation dans lightning. 

"""

def mask_iou(
    mask1: torch.Tensor,
    mask2: torch.Tensor,
) -> torch.Tensor:
    """
    Inputs:
    mask1: [N,H,W] torch.float32. Consists of [0, 1]
    mask2: [M,H,W] torch.float32. Consists of [0, 1]
    Outputs:
    ret: [N,M] torch.float32. Consists of [0 - 1]
    """
    assert len(mask2.shape) == len(mask1.shape), "Mask should have equal shapes"
    assert len(mask1.shape) == 3, "Mask should be Len 3"
    mask1 = mask1.type_as(mask2)
    N, H, W = mask1.shape
    M, H, W = mask2.shape

    mask1 = mask1.view(N, H * W).float()
    mask2 = mask2.view(M, H * W).float()

    intersection = torch.matmul(mask1, mask2.swapaxes(0, 1))

    area1 = mask1.sum(dim=-1)
    area2 = mask2.sum(dim=-1)

    union = (area1[..., None] + area2[None, ...]) - intersection

    ret = torch.where(
        union == 0,
        torch.tensor(0.0, device=mask1.device),
        intersection / union,
    )

    return ret


def mask_overlap(
    mask1: torch.Tensor,
    mask2: torch.Tensor,
):
    """
    Inputs:
    mask1: [N,H,W] torch.float32. Consists of [0, 1]
    mask2: [M,H,W] torch.float32. Consists of [0, 1]
    Outputs:
    ret: [N,M] torch.float32. Consists of [0 - 1]
    """
    assert len(mask2.shape) == len(mask1.shape), "Mask should have equal shapes"
    assert len(mask1.shape) == 3, "Mask should be Len 3"
    mask1 = mask1.type_as(mask2)
    N, H, W = mask1.shape
    M, H, W = mask2.shape

    mask1 = mask1.view(N, H * W).float()
    mask2 = mask2.view(M, H * W).float()

    intersection = torch.matmul(mask1, mask2.swapaxes(0, 1))

    area2 = mask2.sum(dim=-1)

    ret = torch.where(
        area2 == 0,
        torch.tensor(0.0, device=mask1.device),
        intersection / area2[None, ...],
    )
    return ret

def getattr_float(obj: object, property_name: str):
    """We override getattr
    This to make sure we change device and transform outputs to items.

    Args:
        obj (object): _description_
        property_name (str): _description_

    Returns:
        _type_: _description_
    """
    value = getattr(obj, property_name)
    if isinstance(value, torch.Tensor):
        return value.cpu().item()
    return value


@torch.no_grad()
def match_prediction_target(
    predictions: Dict[str, torch.Tensor],
    targets: Dict[str, torch.Tensor],
    iou_threshold: float,
    device: str = "cpu",
    allow_multiple_match: bool = False,
    use_prediction_overlap: bool = False,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """_summary_

    Args:
        prediction (Dict[str,torch.Tensor]): Dictionnary containing predictions
            boxes:torch.Tensor     - [N_pred,4]
            masks: torch.Tensor     - [N_pred,H,W]
            labels: torch.Tensor    - [N_pred]
            scores: torch.Tensor    - [N_pred]
            map_cpu:bool            - default = True

        targets (Dict[str,torch.Tensor]): _description_
            boxes:torch.Tensor     - [N_gt,4]
            masks: torch.Tensor     - [N_gt,H,W]
            labels: torch.Tensor    - [N_gt]
        cls_id (int): _description_
        iou_threshold (float): _description_
        device (str): _description_
        allow_multiple_match (bool): Allow a target to match multiple predictions at the same time
        use_prediction_overlap (bool): Use the prediction overlap to match predictions instead of IoU score.
        Returns:
            matched_target_ids - Tensor[long]
            matched_pred_ids - Tensor[long]
            unmatched_target_ids - Tensor[long]
            unmatched_pred_ids - Tensor[long]
    """
    # Case 1 - No Prediction
    if len(predictions["labels"]) == 0:
        # In this case, we have no prediction of this class
        # Every targets are unmatched
        matched_target_ids = []
        matched_pred_ids = []
        unmatched_target_ids = range(len(targets["labels"]))
        unmatched_pred_ids = []
        matched_targets_per_prediction = []

    # Case 2 - No Groundtruth Matching
    elif len(targets["labels"]) == 0:
        # Every prediction that match are false positive
        matched_target_ids = []
        matched_pred_ids = []
        unmatched_target_ids = []
        unmatched_pred_ids = range(len(predictions["labels"]))
        matched_targets_per_prediction = []
    # Case 3 - We have both
    else:
        unmatched_pred_ids = set(range(len(predictions["labels"])))
        unmatched_target_ids = set(range(len(targets["labels"])))
        # We compute the matrix of masks IoUs... (pre-filtered)
        gt_masks = targets["masks"]
        p_masks = predictions["masks"]
        # We compute the matrix of masks IoUs...
        if len(p_masks.shape) == 4:
            p_masks = p_masks.squeeze(
                1
            )  # we remove dim = 1 because we have [N,1,H,W] mask
        if use_prediction_overlap:
            # Use Inter over Prediction instead of IoU
            pxl_iou = mask_overlap(gt_masks, p_masks)  # n_gt_cls,n_p_cls
        else:
            # Use Inter over Union
            pxl_iou = mask_iou(gt_masks, p_masks)  # n_gt_cls,n_p_cls
        #######################
        # We match predictions
        #######################
        # Initialize an array that will store, for each prediction, the index of the matched ground-truth target.
        # Initialized with -1, which means "no match". Shape: [num_predictions]
        matched_targets_per_prediction = torch.full(
            (pxl_iou.size(1),), -1, dtype=torch.long, device=pxl_iou.device
        )

        if not allow_multiple_match:
            # In this case, each ground-truth (GT) target can be matched to only one prediction.
            # For each GT, we find the prediction with the highest IoU.
            best_iou, prediction_ids = pxl_iou.max(dim=1)  # Shape: [num_gt]

            # Only retain matches where the best IoU exceeds the threshold
            matching_mask = best_iou > iou_threshold

            # Extract the indices of predictions and corresponding GTs that meet the threshold
            matched_pred_ids = prediction_ids[matching_mask]  # Shape: [num_matched_gt]
            matched_target_ids = torch.arange(len(targets["labels"]))[
                matching_mask
            ]  # Shape: [num_matched_gt]

            # For each matched prediction, store the index of the GT it matches
            matched_targets_per_prediction[matched_pred_ids] = matched_target_ids
        else:
            # In this case, multiple predictions can match the same GT (1-to-many).
            # Find all prediction-GT pairs where IoU exceeds the threshold
            pxl_iou_matches = (
                pxl_iou > iou_threshold
            ).nonzero()  # Shape: [num_matches, 2]

            # Split the match pairs into GT and prediction indices
            matched_target_ids = pxl_iou_matches[:, 0]
            matched_pred_ids = pxl_iou_matches[:, 1]

            # For each matched prediction, store the corresponding GT index
            # Note: if a prediction matches multiple GTs, only the last one is kept here
            matched_targets_per_prediction[matched_pred_ids] = matched_target_ids

        matched_target_ids = matched_target_ids.tolist()
        matched_pred_ids = matched_pred_ids.tolist()

        # We create Outputs of the function.
        unmatched_pred_ids = list(unmatched_pred_ids.difference(set(matched_pred_ids)))
        unmatched_target_ids = list(
            unmatched_target_ids.difference(set(matched_target_ids))
        )
    # We create outputs as tensors
    matched_target_ids = torch.tensor(matched_target_ids, device=device).long()
    matched_pred_ids = torch.tensor(matched_pred_ids, device=device).long()
    unmatched_target_ids = torch.tensor(unmatched_target_ids, device=device).long()
    unmatched_pred_ids = torch.tensor(unmatched_pred_ids, device=device).long()
    matched_targets_per_prediction = torch.tensor(
        matched_targets_per_prediction, device=device
    ).long()
    return (
        matched_target_ids,
        matched_pred_ids,
        unmatched_target_ids,
        unmatched_pred_ids,
        matched_targets_per_prediction,
    )


class MaskRCnnVerdict(Metric):

    def __init__(self,         
        clsNames: Dict[str, int],
        num_thresholds: int = 20,
        iou_threshold: float = 0.5,
        mask_proba_threshold: float = 0.5,
        plot_f1: bool = True,
        allow_multiple_match: bool = True,
        use_prediction_overlap: bool = False,
        eps: float = 1e-6,):

        super().__init__()
        self.num_thresholds = num_thresholds
        self.score_thresholds = torch.linspace(0, 1, self.num_thresholds)
        self.num_classes = len(list(set(clsNames.values())))
        self.eps = eps
        self.iou_threshold = iou_threshold
        self.mask_proba_threshold = mask_proba_threshold
        self.use_prediction_overlap = use_prediction_overlap
        self.plot_f1 = plot_f1
        self.allow_multiple_match = allow_multiple_match
        # We build a dictionnary inversed that map cls => Dict
        clsIDs_map = {}
        # We handle case where we merge classes...
        for k, v in clsNames.items():
            current_map = clsIDs_map.get(v, [])
            current_map.append(k)
            # We add the class to the map
            clsIDs_map[v] = current_map
        self.cls_id_to_name = {k: "_".join(v) for k, v in clsIDs_map.items()}
        self.clsIDs = list(self.cls_id_to_name.keys())

        self.add_state(
            "true_positive_buffer", 
            torch.zeros((self.num_classes, self.num_thresholds)), 
            dist_reduce_fx=sum
        )
        self.add_state(
            "false_positive_buffer", 
            torch.zeros((self.num_classes, self.num_thresholds)),
            dist_reduce_fx=sum
        )
        self.add_state(
            "false_negative_buffer", 
            torch.zeros((self.num_classes, self.num_thresholds)),
            dist_reduce_fx=sum
        )

    def _update_image(
        self, predictions: Dict[str, torch.Tensor], targets: Dict[str, torch.Tensor]
    ):
        """Update verdicts from a prediction and it's targets.

        Args:
            prediction (Dict[str,torch.Tensor]): Dictionnary containing predictions
                boxes:torch.Tensor     - [N_pred,4]
                masks: torch.Tensor     - [N_pred,H,W]
                labels: torch.Tensor    - [N_pred]
                scores: torch.Tensor    - [N_pred]

            targets (Dict[str,torch.Tensor]): _description_
                boxes:torch.Tensor     - [N_pred,4]
                masks: torch.Tensor     - [N_pred,H,W]
                labels: torch.Tensor    - [N_pred]
        """
        assert isinstance(predictions, dict), "predictions should be a dict"
        assert isinstance(targets, dict), "targets should be a dict"
        # We compute masks > thresholds
        predictions["masks"] = (
            predictions["masks"] >= self.mask_proba_threshold
        ).float()

        unique_ids = set(torch.cat([predictions["labels"], targets["labels"]]).tolist())
        # We compute every verdicts
        for cls_id in unique_ids:
            # We filter predictions / targets from cls_id
            targets_cls_msk = targets["labels"] == cls_id
            targets_cls = {
                k: v[targets_cls_msk]
                for k, v in targets.items()
                if isinstance(v, torch.Tensor)
            }
            predictions_cls_msk = predictions["labels"] == cls_id
            predictions_cls = {
                k: v[predictions_cls_msk]
                for k, v in predictions.items()
                if isinstance(v, torch.Tensor)
            }
            # We match predictions and targets...
            (
                matched_target_ids,
                matched_pred_ids,
                unmatched_target_ids,
                unmatched_pred_ids,
                matched_targets_per_prediction,
            ) = match_prediction_target(
                predictions_cls,
                targets_cls,
                self.iou_threshold,
                device=self.device,
                allow_multiple_match=self.allow_multiple_match,
                use_prediction_overlap=self.use_prediction_overlap,
            )

            # Create an empty tensor to safely retrieve missing prediction keys without errors
            empty = torch.tensor([], device=self.true_positive_buffer.device)

            # Retrieve prediction scores (or use empty tensor if key not found)
            pred_scores = predictions_cls.get("scores", empty)  # Shape: [N]
            pred_scores_exp = pred_scores[
                :, None
            ]  # Expand to [N, 1] for broadcasting against thresholds

            # Prepare thresholds and move them to the same device as prediction scores
            thresholds_exp = self.score_thresholds.clone().to(
                pred_scores.device
            )  # Shape: [K]

            # Compute boolean mask: for each prediction, whether it passes each threshold
            # Shape: [N, K] => N predictions, K thresholds
            valid_pred_mask = pred_scores_exp >= thresholds_exp

            # Count false positives: unmatched predictions that still pass thresholding
            # Sum over unmatched prediction indices
            fp_counts = valid_pred_mask[unmatched_pred_ids].sum(dim=0)  # Shape: [K]

            # Initialize false negative counter
            fn_counts = torch.zeros(
                len(thresholds_exp), device=pred_scores.device
            )  # Shape: [K]

            # Extract only the matched predictions that passed thresholding
            matched_valid = valid_pred_mask[matched_pred_ids]  # Shape: [M, K]

            # Create a matrix to track which ground-truths are matched per threshold
            # Shape: [num_unique_GT_ids, K]
            gt_valid_ids = torch.zeros(
                (
                    len(set(matched_target_ids.tolist()))
                    + len(set(unmatched_target_ids.tolist())),
                    len(thresholds_exp),
                ),
                dtype=torch.bool,
                device=pred_scores.device,
            )

            # For each matched prediction, register valid thresholds for the matched GT
            for i, pred_id in enumerate(matched_pred_ids):
                gt_id = matched_targets_per_prediction[pred_id]
                if gt_id != -1:  # Only process predictions with valid GT match
                    # If prediction i is valid under threshold k, mark that GT as matched under k
                    gt_valid_ids[gt_id] |= matched_valid[i]

            # Count how many GTs have at least one valid prediction per threshold
            gt_has_valid_match = gt_valid_ids.sum(dim=0)  # Shape: [K]
            gt_has_no_valid_match = (~gt_valid_ids).sum(dim=0)  # Shape: [K]

            tp_counts = gt_has_valid_match  # True Positives: GTs with valid matches
            fn_counts += (
                gt_has_no_valid_match  # False Negatives: GTs without valid matches
            )

            # Update cumulative performance buffers for the class
            self.true_positive_buffer[cls_id] += tp_counts
            self.false_positive_buffer[cls_id] += fp_counts
            self.false_negative_buffer[cls_id] += fn_counts
    
    def update(self, preds: list[dict[str, Tensor]], target: list[dict[str, Tensor]]):
        """Update the metric state with predictions and targets.

        Args:
            preds (list[dict[str, Tensor]]): List of dictionaries containing predictions.
                Each dictionary should contain the following keys:
                    - 'boxes': Tensor of shape [N_pred, 4]
                    - 'masks': Tensor of shape [N_pred, H, W]
                    - 'labels': Tensor of shape [N_pred]
                    - 'scores': Tensor of shape [N_pred]
            target (list[dict[str, Tensor]]): List of dictionaries containing ground truth targets.
                Each dictionary should contain the following keys:
                    - 'boxes': Tensor of shape [N_gt, 4]
                    - 'masks': Tensor of shape [N_gt, H, W]
                    - 'labels': Tensor of shape [N_gt]
        """
        for prediction, target in zip(preds, target):
            self._update_image(prediction, target)

    def _true_positive(self, threshold_id: int, cls_id: int):
        return self.true_positive_buffer[cls_id, threshold_id].cpu().item()

    def _false_positive(self, threshold_id, cls_id: int):
        return self.false_positive_buffer[cls_id, threshold_id].cpu().item()

    def _false_negative(self, threshold_id, cls_id: int):
        return self.false_negative_buffer[cls_id, threshold_id].cpu().item()

    def _f1_score(self, threshold_id: int, cls_id: int):
        recall = self._recall(threshold_id, cls_id)
        precision = self._precision(threshold_id, cls_id)
        return 2 * (precision * recall) / (precision + recall + self.eps)

    def _f2_score(self, threshold_id: int, cls_id: int):
        recall = self._recall(threshold_id, cls_id)
        precision = self._precision(threshold_id, cls_id)
        return (
            (1 + 2**2) * (precision * recall) / ((2**2) * precision + recall + self.eps)
        )

    def _recall(self, threshold_id: int, cls_id: int) -> float:
        """Recall = TP/(TP+FN)

        Args:
            cls_id (int): _description_
            threshold (int): _description_
        """
        tp = self._true_positive(threshold_id, cls_id)
        fn = self._false_negative(threshold_id, cls_id)
        recall = tp / (tp + fn + self.eps)
        return recall

    def _precision(self, threshold_id: int, cls_id: int):
        """Precision = TP/(TP+FP)

        Args:
            cls_id (int): _description_
            threshold (int): _description_

        Returns:
            _type_: _description_
        """
        tp = self._true_positive(threshold_id, cls_id)
        fp = self._false_positive(threshold_id, cls_id)
        precision = tp / (tp + fp + self.eps)
        return precision

    def _auc(self, cls_id: int):
        """AUC = Area under the precision recall curve

        Args:
            cls_id (int): _description_

        Returns:
            _type_: _description_
        """
        p_r_points = [
            (self._recall(t, cls_id), self._precision(t, cls_id))
            for t in range(self.num_thresholds)
        ]
        p_r_points.sort(key=lambda point: point[0])
        if (0, 0) in p_r_points:
            p_r_points.remove((0, 0))
        p_r_points.insert(0, (0, 1))
        p_r_points.append((1, 0))

        # We compute AUC
        auc = 0
        for i in range(len(p_r_points) - 1):
            auc += p_r_points[i][1] * (p_r_points[i + 1][0] - p_r_points[i][0])
        return auc

    def compute(self):
        results = {}
        global_true_positive = 0
        global_false_positive = 0
        global_false_negative = 0
        for cls_id, cls_name in self.cls_id_to_name.items():
            if cls_name.lower() != "background":
                f1_scores = [
                    self._f1_score(t, cls_id) for t in range(self.num_thresholds)
                ]
                best_f1_score = np.max(f1_scores)
                threshold_id = np.argmax(f1_scores)
                # We compute the metrics at the best threshold
                threshold = self.score_thresholds[threshold_id]
                recall = self._recall(threshold_id, cls_id)
                precision = self._precision(threshold_id, cls_id)
                num_true_positive = self._true_positive(threshold_id, cls_id)
                num_false_positive = self._false_positive(threshold_id, cls_id)
                num_false_negative = self._false_negative(threshold_id, cls_id)
                # We append to the global buffer, metrics at this threshold.
                global_true_positive += num_true_positive
                global_false_positive += num_false_positive
                global_false_negative += num_false_negative
                # We add results for this class...
                results[f"{cls_name}-f1-score"] = best_f1_score
                results[f"{cls_name}-recall"] = recall
                results[f"{cls_name}-precision"] = precision
                results[f"{cls_name}-threshold"] = threshold.item()
        # We compute global results..
        global_recall = global_true_positive / (
            global_true_positive + global_false_negative + self.eps
        )
        global_precision = global_true_positive / (
            global_true_positive + global_false_positive + self.eps
        )
        global_f1 = (
            2
            * (global_recall * global_precision)
            / (global_precision + global_recall + self.eps)
        )
        global_f2 = (
            (1 + 2**2)
            * (global_recall * global_precision)
            / ((2**2) * global_precision + global_recall + self.eps)
        )
        results["global-f1-score"] = global_f1
        results["global-f2-score"] = global_f2
        results["global-precision"] = global_precision
        results["global-recall"] = global_recall
        
        return results    