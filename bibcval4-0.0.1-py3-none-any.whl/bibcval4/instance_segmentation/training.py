import lightning as L

import torch
from bibcvmodels.segmentation.instance import MaskRCNN_Bib, MaskRCNNConfig
from bibcvmodels.segmentation.instance.maskrcnn.nms import MaskrcnnNMS
import torchmetrics
from .mascrnn_tmc_metric import MaskRCnnVerdict


class instanceModule(L.LightningModule):
    def __init__(self, config, train_ds, MIN_SIZE):
        super().__init__()
        # if config.checkpoint is not None:
        # print(f"checkpoint from {config.checkpoint}")
        # self.model = MaskRCNN_Bib.load_checkpoint(config.checkpoint)
        self.model = MaskRCNN_Bib(
            config=MaskRCNNConfig(
                num_channels=4,
                clsNames=train_ds.clsNames,
                image_mean=[
                    0.449,
                    0.449,
                    0.449,
                ],  # Like Deepsense (mean Imagenet) 0.449
                image_std=[0.227, 0.227, 0.227],  # Like Deepsense 0.227 = 1/4.392
                rpn_fg_iou_thresh=0.5,
                rpn_bg_iou_thresh=0.1,
                box_fg_iou_thresh=0.3,  # Like Deepsense
                box_bg_iou_thresh=0.1,
                version=1,
                min_size=MIN_SIZE,
            )
        )
        self.mask_proba_threshold = 0.5

        metrics = torchmetrics.MetricCollection([
            MaskRCnnVerdict(
                clsNames = train_ds.clsNames,
                num_thresholds = 20,
                iou_threshold = 0.5,
                mask_proba_threshold = 0.5,
                allow_multiple_match = True,
                use_prediction_overlap = False,
            )
        ])

        self.train_metrics = metrics.clone(prefix="Train/")
        self.val_metrics = metrics.clone(prefix="Validation/")
        self.test_metrics = metrics.clone(prefix="Test/")
        
        self.nms = MaskrcnnNMS(
            nms_threshold=0.1,
            mask_proba_threshold=0.5,
            clsNames=train_ds.clsNames,
            use_iou=False,
            per_classes=True,
        )
        self.config = config
        self.save_hyperparameters(ignore=["train_ds"])

    @staticmethod
    def prepare_batch(batch):
        images, targets = batch
        return images, targets

    def forward(self, x, y=None):
        if y is not None:
            return self.model(x, y)
        else:
            preds = self.model(x)
            return preds

    def predict(self, x):
        """Forward the model then run NMS (for evaluation)

        Args:
            x (_type_): _description_

        Returns:
            _type_: _description_
        """        
        preds = self.model(x)
        preds_nms = self.nms.apply_batch(preds)
        
        # for i in preds_nms:
        #     if len(i["boxes"]) >0:
        #         i["masks"] = (i["masks"] > self.mask_proba_threshold)
        #         i["masks"] = i["masks"].squeeze(1)
        
        return preds_nms

    def forward_proba(self, x):
        """used in AL functions, in Instance segmentaiton == forward

        Args:
            x (_type_): _description_

        Returns:
            _type_: _description_
        """        
        return self.forward(x)

    def forward_embedding(self, x):
        """used in Core-Set algorithms the create the embedding matrix

        Args:
            x (_type_): _description_

        Returns:
            _type_: _description_
        """        
        bs = len(x)
        images = torch.stack(x)
        return self.model.model.backbone(images)["pool"].view(bs, -1)

    def training_step(self, batch, batch_idx):
        img_b, target_b = self.prepare_batch(batch)
        bs = len(img_b)

        loss_dict = self.model(img_b, target_b)
        
        self.log_dict(
            loss_dict,
            on_epoch=True,
            sync_dist=False,
            batch_size=bs,
        )

        return {"loss": loss_dict["loss_total"]}

    def validation_step(self, batch, batch_idx):
        img_b, target_b = self.prepare_batch(batch)
        output_nms = self.predict(img_b)

        self.val_metrics(output_nms, target_b)

        return

    def on_validation_epoch_end(self):
        
        m = self.val_metrics.compute()
        
        self.log_dict(m, on_epoch=True, sync_dist=False)

        self.val_metrics.reset()
        return

    def test_step(self, batch, batch_idx):
        img_b, target_b = self.prepare_batch(batch)

        output_nms = self.predict(img_b)
        # for images in target_b:
        #     images["masks"] = images["masks"] > 0
        self.test_metrics(output_nms, target_b)
        return

    def on_test_epoch_end(self):
        self.log_dict(self.test_metrics.compute(), on_epoch=True, sync_dist=False)

        self.test_metrics.reset()
        return 

    def configure_optimizers(self):

        optimizer = torch.optim.AdamW(
            self.parameters(),
            lr=self.config.lr * self.config.world_size,
            weight_decay=1e-4 * self.config.batch_size / 16,
            eps=1e-8,
        )
    
        scheduler_nsteps = self.config.epochs * self.config.world_size
        scheduler1 = torch.optim.lr_scheduler.MultiStepLR(
            optimizer, milestones=[scheduler_nsteps//2,scheduler_nsteps*3//4,scheduler_nsteps*7//8],
            gamma = .5
        )

        sched_config1 = {"scheduler": scheduler1, "interval": "epoch"}

        # scheduler2 = torch.optim.lr_scheduler.LinearLR(optimizer,start_factor=0.001,total_iters=500)
        # sched_config2 = {
        #         "scheduler" : scheduler2,
        #         "interval": "step"
        #     }

        return [optimizer], [sched_config1]

if __name__ == "__main__":
    model = instanceModule()