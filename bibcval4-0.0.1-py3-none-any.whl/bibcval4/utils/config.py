from omegaconf import OmegaConf


def load_config(path: str, check_config:bool = True):
    """oad a config file using OmegaConf

    Args:
        path (str): config file path
        check_config (bool, optional): Wether we need to chec kif the config file is suitable for al_loop func.

    Returns:
        _type_: _description_
    """    
    config = OmegaConf.load(path)
    if check_config:
        test_config(config)
    return config


def test_config(config):
    required_fields = ["lr", "batch_size", "cycles", "repetitions", "epochs", "workers"]
    problems = []
    for i in required_fields:
        if i not in config:
            problems.append(i)

    if len(problems) > 0:
        raise KeyError(
            f"{problems} needs to be defined in config. \n required fields are {required_fields}"
        )
