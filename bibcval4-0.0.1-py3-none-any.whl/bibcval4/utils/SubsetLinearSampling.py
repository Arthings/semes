from torch.utils.data import Sampler


class SubsetLinearSampler(Sampler):
    """Sample a dataset from given indices not randomly

    Args:
        Sampler (_type_): _description_
    """    
    def __init__(self, indices):
        self.indices = indices

    def __iter__(self):
        return iter(self.indices)

    def __len__(self):
        return len(self.indices)
