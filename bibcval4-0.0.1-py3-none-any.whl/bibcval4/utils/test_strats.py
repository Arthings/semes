import numpy as np
from typing import Tuple

def test_strat(
    labeled: np.ndarray, unlabeled: np.ndarray, selected: np.ndarray, budget: int, cycle:int
)-> None:
    """check 3 conditions on selected items 
        - budget items have been slected
        - selected indices or not in the labeled_indices
        - selected items are all coming from unlabeled indices

    Args:
        labeled (np.ndarray): _description_
        unlabeled (np.ndarray): _description_
        selected (np.ndarray): _description_
        budget (int): _description_
    """    

    # Check if we selected the good number of items
    assert len(np.unique(selected)) == budget, (
        f"selected {len(np.unique(selected))} unique items instead of {budget}"
    )

    # check if we selected items from the unlabeled dataset
    assert np.isin(selected, labeled).sum() == 0, (
        f"{np.isin(selected, labeled).sum()} labeled items have been selected"
    )

    # check if all the selected items are in the unlabeled dataset
    assert np.isin(selected, unlabeled).sum() == budget, (
        f"{budget - np.isin(selected, unlabeled).sum()} selected items"
    )

    # check if the number of labeled items match the cycles/budget
    # assert len(labeled)+len(selected) ==  (cycle+1) * budget, f"{len(labeled)=} should be equal to {(cycle+1) * budget=}"
