from accelerate.utils import ProjectConfiguration
import os 

import accelerate
import matplotlib.pyplot as plt 

"""
Taken from bibcvmodels
"""

def add_test_entry(test_dict, tracker_name, tag, value, step):
    if tracker_name not in test_dict:
        test_dict[tracker_name] = {}
    if tag not in test_dict[tracker_name]:
        test_dict[tracker_name][tag] = {}
    test_dict[tracker_name][tag][step] = value

class Accelerator(accelerate.Accelerator):
    def log_figure(self, tag: str, figure: plt.Figure, global_step: int) -> None:
        """This method log a figure in tensorboard.

        Args:
            figure (plt.Figure): _description_
            global_step (int): _description_
        """
        if self.is_main_process:
            for tracker in self.trackers:
                if tracker.name == "tensorboard":
                    tracker.writer.add_figure(tag, figure, global_step)

        plt.close(figure)


def make_accelerator(config:str, tracking_type ="tensorboard") -> Accelerator:
    """Set the accelerator with the good path given the specified logging method( tensorflow, mlflow, wandb ...)

    """        
    # profile_kwargs = accelerate.ProfileKwargs(
    #     activities=["cpu", "cuda"],
    #     output_trace_dir="./logs/trace"
    # )

    project_config = ProjectConfiguration(project_dir="logs/", logging_dir="logs/")
    # accelerator= accelerate.Accelerator(log_with = tracking_type, project_config = config, mixed_precision="no")
    accelerator = Accelerator(log_with = tracking_type, project_config = project_config, mixed_precision="no")
    if tracking_type == "mlflow" or tracking_type == "all":
        os.makedirs("mlruns/", exist_ok= True) 
        
    accelerator.init_trackers(f"myProject_{config['acquisition_function']}")#, config = config)
    print(f"{accelerator.device=}")
    return accelerator
