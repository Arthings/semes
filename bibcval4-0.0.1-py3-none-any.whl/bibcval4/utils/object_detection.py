from typing import Dict, Tuple, List
import torch
import torch.nn as nn
from dataclasses import dataclass, field


@dataclass
class odNMS:
    nms_threshold: float = field(default=0.5)
    clsNames: dict = field(default_factory=dict)
    per_classes: bool = field(default=True)
    use_iou: bool = field(default=True)

    def __post_init__(self):
        self.overlap_func = mask_iou if self.use_iou else mask_overlap

    def apply_batch(self, batch_predictions: List[Dict[str, torch.Tensor]]):
        """Update predictions from a batch of predictions

        Args:
            batch_predictions (List[Dict[str,torch.Tensor]]):

        Returns:
            batch_predictions(List[Dict[str,torch.Tensor]]):
                Each Dictionnary containing predictions
                    boxes: torch.Tensor     - [N_nms,4]
                    masks: torch.Tensor     - [N_nms,H,W]
                    labels: torch.Tensor    - [N_nms]
                    scores: torch.Tensor    - [N_nms]
        """
        result = []
        for instance in batch_predictions:
            result.append(self.__call__(instance))
        return result

    def __call__(self, predictions_instance: Dict[str, torch.Tensor]):
        """Update predictions from an instance prediction.
        Args:
            prediction (Dict[str,torch.Tensor]): Dictionnary containing predictions
                boxes: torch.Tensor     - [N_pred,4]
                labels: torch.Tensor    - [N_pred]
                scores: torch.Tensor    - [N_pred]
        Returns:
            prediction (Dict[str,torch.Tensor]): Dictionnary containing predictions
                boxes: torch.Tensor     - [N_nms,4]
                labels: torch.Tensor    - [N_nms]
                scores: torch.Tensor    - [N_nms]
        """
        assert isinstance(predictions_instance, dict), "predictions should be a dict"
        list_of_predictions = self._prediction_dict_to_list(predictions_instance)
        # Remove empty Predictions
        list_of_predictions = [
            p for p in list_of_predictions if not (p["boxes"] == 0).all()
        ]
        # If the list is empty, return empty tensors
        if len(list_of_predictions) == 0:
            return {
                "boxes": torch.tensor([]).to(predictions_instance["boxes"].device),
                "labels": torch.tensor([], dtype=torch.int).to(
                    predictions_instance["labels"].device
                ),
                "scores": torch.tensor([]).to(predictions_instance["scores"].device),
            }

        list_of_predictions_after_nms = []
        if self.per_classes:
            unique_ids = set(predictions_instance["labels"].tolist())
            for cls_id in unique_ids:
                prediction_group = [
                    x for x in list_of_predictions if x["label"] == cls_id
                ]
                list_of_predictions_after_nms.extend(self._nms(prediction_group))
        else:
            list_of_predictions_after_nms = self._nms(predictions_instance)
        # We re-transform prediction to dictionnary
        predictions_after_nms = self._prediction_list_to_dict(
            list_of_predictions_after_nms
        )
        return predictions_after_nms

    def _nms(
        self, pred_group: List[Dict[str, torch.Tensor]]
    ) -> List[Dict[str, torch.Tensor]]:
        """Process NMS for a group
        Args:
            prediction List[Dict[str,torch.Tensor]]:
                List of Dictionnary containing predictions
                boxe: torch.Tensor      - [4]
                label: torch.Tensor     - 1
                score: torch.Tensor     - 1
        Returns:
            List[Dict[str,torch.Tensor]]: _description_
        """

        pred_sorted = sorted(pred_group, key=lambda x: x["score"], reverse=True)
        pred_after_nms = []
        while len(pred_sorted) > 1:
            current_pred = pred_sorted.pop(0)
            pred_after_nms.append(current_pred)
            if len(current_pred["mask"].shape) == 3:
                # Mask are [1,H,W] => hasis
                ious = self.overlap_func(
                    current_pred["mask"] > self.mask_proba_threshold,
                    torch.cat([x["mask"] for x in pred_sorted]),
                ).squeeze(dim=0)
            else:
                # Mask are [H,W] => unsqueeze + stack
                ious = self.overlap_func(
                    current_pred["mask"].unsqueeze(0),
                    torch.stack([x["mask"] for x in pred_sorted]),
                ).squeeze(dim=0)
            # We remove, unreleavant predictions
            pred_sorted = [
                x for i, x in enumerate(pred_sorted) if ious[i] < self.nms_threshold
            ]
        # We add the last prediction
        pred_after_nms.extend(pred_sorted)
        return pred_after_nms

    def _prediction_dict_to_list(
        self, predictions: Dict[str, torch.Tensor]
    ) -> List[Dict[str, torch.Tensor]]:
        """Update verdicts from a prediction and it's targets.
        Args:
            prediction (Dict[str,torch.Tensor]): Dictionnary containing predictions
                boxes: torch.Tensor     - [N_pred,4]
                masks: torch.Tensor     - [N_pred,H,W]
                labels: torch.Tensor    - [N_pred]
                scores: torch.Tensor    - [N_pred]
        Returns:
            prediction: List containing Prediction Dict
                boxe: torch.Tensor     - [N_nms,4]
                mask: torch.Tensor     - [N_nms,H,W]
                label: torch.Tensor    - [N_nms]
                score: torch.Tensor    - [N_nms]
        """
        boxes = predictions["boxes"]
        masks = predictions["masks"]
        labels = predictions["labels"]
        scores = predictions["scores"]
        if not len(boxes):
            # Handle case empty
            # => Necessary for empty mask to keep right shape.
            self.empty = predictions
        return [
            {
                "boxe": boxes[i],
                "mask": masks[i],
                "label": labels[i],
                "score": scores[i],
            }
            for i in range(len(boxes))
        ]

    def _prediction_list_to_dict(
        self, predictions: List[Dict[str, torch.Tensor]]
    ) -> Dict[str, torch.Tensor]:
        """Update verdicts from a prediction and it's targets.
        Args:
            prediction: List containing Prediction Dict
                List[N_pred] of Dict[str,torch.Tensor]
                boxe: torch.Tensor      - [4]
                mask: torch.Tensor      - [H,W]
                label: float            - 1
                score: float            - 1
        Returns:
            prediction (Dict[str,torch.Tensor]): Dictionnary containing predictions
                boxes: torch.Tensor     - [N_pred,4]
                masks: torch.Tensor     - [N_pred,H,W]
                labels: torch.Tensor    - [N_pred]
                scores: torch.Tensor    - [N_pred]
        """
        if len(predictions):
            boxes = torch.stack([x["boxe"] for x in predictions])
            masks = torch.stack([x["mask"] for x in predictions])
            # We force labels and score to be on same device as others
            labels = torch.tensor([x["label"] for x in predictions]).to(boxes.device)
            scores = torch.tensor([x["score"] for x in predictions]).to(boxes.device)
            return {"boxes": boxes, "masks": masks, "labels": labels, "scores": scores}
        else:
            # We return empty prediction.
            return self.empty

def mask_iou(
    mask1: torch.Tensor,
    mask2: torch.Tensor,
) -> torch.Tensor:
    """
    Inputs:
    mask1: [N,H,W] torch.float32. Consists of [0, 1]
    mask2: [M,H,W] torch.float32. Consists of [0, 1]
    Outputs:
    ret: [N,M] torch.float32. Consists of [0 - 1]
    """
    assert len(mask2.shape) == len(mask1.shape), "Mask should have equal shapes"
    assert len(mask1.shape) == 3, "Mask should be Len 3"
    mask1 = mask1.type_as(mask2)
    N, H, W = mask1.shape
    M, H, W = mask2.shape

    mask1 = mask1.view(N, H * W).float()
    mask2 = mask2.view(M, H * W).float()

    intersection = torch.matmul(mask1, mask2.swapaxes(0, 1))

    area1 = mask1.sum(dim=-1)
    area2 = mask2.sum(dim=-1)

    union = (area1[..., None] + area2[None, ...]) - intersection

    ret = torch.where(
        union == 0,
        torch.tensor(0.0, device=mask1.device),
        intersection / union,
    )

    return ret


def mask_overlap(
    mask1: torch.Tensor,
    mask2: torch.Tensor,
):
    """
    Inputs:
    mask1: [N,H,W] torch.float32. Consists of [0, 1]
    mask2: [M,H,W] torch.float32. Consists of [0, 1]
    Outputs:
    ret: [N,M] torch.float32. Consists of [0 - 1]
    """
    assert len(mask2.shape) == len(mask1.shape), "Mask should have equal shapes"
    assert len(mask1.shape) == 3, "Mask should be Len 3"
    mask1 = mask1.type_as(mask2)
    N, H, W = mask1.shape
    M, H, W = mask2.shape

    mask1 = mask1.view(N, H * W).float()
    mask2 = mask2.view(M, H * W).float()

    intersection = torch.matmul(mask1, mask2.swapaxes(0, 1))

    area2 = mask2.sum(dim=-1)

    ret = torch.where(
        area2 == 0,
        torch.tensor(0.0, device=mask1.device),
        intersection / area2[None, ...],
    )
    return ret


if __name__ == "__main__":
    import cv2
    import urllib
    import numpy as np
    from torchvision.models.detection import fasterrcnn_mobilenet_v3_large_fpn
    from torchvision.utils import draw_bounding_boxes
    import matplotlib.pyplot as plt
    model = fasterrcnn_mobilenet_v3_large_fpn(pretrained=False)

    req = urllib.request.urlopen('https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fhost.robots.ox.ac.uk%2Fpascal%2FVOC%2Fvoc2012%2Fsegexamples%2Fimages%2F21.jpg&f=1&nofb=1&ipt=f3eb77a37e871694c985a6c8b3b726d68134826d3754b8fddd9652af7dee1b0a')
    arr = np.asarray(bytearray(req.read()), dtype=np.uint8)
    img = cv2.imdecode(arr, -1) # 'Load it as it is'
    img = torch.from_numpy(img)
    plt.imshow(img.numpy())
    img = img.permute(2,0,1).unsqueeze(0)/255
    model.eval()
    preds = model(img)
    preds
    with_boxes = draw_bounding_boxes(
        img[0],
        preds[0]["boxes"],
        labels=[str(i) for i in preds[0]["labels"]],
    )
    plt.imshow(with_boxes.permute(1,2,0).numpy())

    preds
    pred_image = preds[0]
    unique_predicted_labels = set(pred_image["labels"].numpy())
    for label in unique_predicted_labels:
        label_boxes = pred_image["boxes"][pred_image["labels"] == label]
        label_scores= pred_image["scores"][pred_image["labels"] == label]
        print(label_boxes)
        print(label_scores)
        keep_indices = cv2.dnn.NMSBoxes(
            bboxes=label_boxes.tolist(),
            scores = label_scores.tolist(),
            score_threshold=.5,
            nms_threshold=0.5,
        )
        print(keep_indices)