import torch
import numpy as np 
import random 
from typing import Optional

def make_determinist(seed: Optional[int]):
    """_summary_

    Taken from bibcvmodels
     ? Copy with pride ?

    Args:
        seed (int, optional): _description_. Defaults to 42.
    """    
    if seed is not None:
        torch.random.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)
        # torch.use_deterministic_algorithms(True, warn_only = True)
