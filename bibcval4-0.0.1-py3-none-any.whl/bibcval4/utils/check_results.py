import os
import pandas as pd

def parse_file(path:str):
    bias = path.split("/")[8]
    strat = path.split("/")[-1].split("_")[2][:-8]
    reset_model = path.split("/")[-1].split("_")[3][:-4]
    df = pd.read_csv(path, sep = ";", index_col = 0).iloc[:,:-1]
    return (
        df
        .assign(bias = bias)
        .assign(strat  =strat)
        .assign(reset_model = reset_model)
        .assign(labeled_items = lambda df_: (df_.cycle + 1) * 100)
    )


def parse_dir(path: str)->pd.DataFrame:
    metrics_files = []
    for root, dirs, files in os.walk(path):
        if "pl_logs" in dirs:
            dirs.remove("pl_logs")
        for file in files:
            print(file)
            if file.endswith(".csv") and file.startswith("rep"):
                metrics_files.append(os.path.join(root, file))
    return pd.concat([parse_file(f) for f in metrics_files])
      