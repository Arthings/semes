import os 
from typing import Dict 

"""
use to consctruct the csv file for global logging along cycles


"""

def make_file_name(config):
    reset = "RESET" if config.reset_model else "KEEP"
    fname = f"replication_metrics_{config.strat}_{reset}.csv"
    
    return fname

def setup_logging_file(config)->None:
    """Create a CSV in path to be filled alors cycles

    Args:
        path (str, optional): _description_. Defaults to "./logs".
    """    
    output_folder= os.path.join(config.log_dir, "replication_metrics")
    os.makedirs(output_folder, exist_ok=True)
    
    fname =make_file_name(config)

    with open(os.path.join(output_folder, fname), "w") as f:
        f.write("metric;cycle;repetition;labeled_items;\n")


def log_to_file(data:Dict, config)->None:
    """write val_metric in the csv along rounds

    Args:
        data (Dict): dict with 2 keys : metric and
        path (str, optional): _description_. Defaults to "./logs".
    """    

    output_folder= os.path.join(config.log_dir, "replication_metrics")
    os.makedirs(output_folder, exist_ok=True)
    
    fname = make_file_name(config)
 
    with open(os.path.join(output_folder, fname), "a") as f:
        for key in data:
            f.write(str(data[key]))
            f.write(";")
        f.write("\n")
