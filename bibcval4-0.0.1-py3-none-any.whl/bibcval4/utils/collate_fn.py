import torch
from typing import List, Any, Iterable


def maskrcnn_collate_fn(batchs: List[Any]):
    """We need to define a custom collate function to handle bboxes that can be different size.

    Documentation :
            https://pytorch.org/tutorials/intermediate/torchvision_tutorial.html
    The maskrcnn is expecting :
        image = a List of Images
        target = a list of dictionnary containing :
            - boxes
            - masks
            - labels
            - image_id

    Args:
        batch (List[Any]): _description_

    Returns:
        Tuple(Images,Targets):
    """
    images = []
    targets = []
    for i, item in enumerate(batchs):
        c, h, w = item["image"].shape
        images.append(item["image"])
        target = dict(
            boxes=torch.zeros((0, 4)),
            masks=torch.zeros((0, h, w)),
            labels=torch.zeros((0,), dtype=torch.int64),
            image_id=item["name"],
        )
        # We override with annotation when there are.
        if len(item["labels"]) > 0:
            for key in ["boxes", "masks", "labels"]:
                if isinstance(item[key], list):
                    if isinstance(item[key][0], Iterable):
                        # case list of tensor/np.array/list/tuple
                        if isinstance(item[key][0], torch.Tensor):
                            target[key] = torch.stack(item[key])
                        else:
                            target[key] = torch.stack(
                                [torch.tensor(k) for k in item[key]]
                            )
                    else:
                        # case list of int
                        target[key] = torch.tensor(item[key])
                else:
                    # case numpy array or tensor
                    target[key] = torch.tensor(item[key])
        targets.append(target)
    return images, targets
