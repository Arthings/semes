from torch.utils.data import Dataset
import os
from typing import Optional
from omegaconf import DictConfig
def check_proc(
    dataset: Dataset,
    config: DictConfig,
    precomputed_features: Optional[str],
    lightning_module
)-> None:
    """Check is the active learning procedure can start

    Args:
        dataset (Dataset): _description_
        config (_type_): _description_
    """    
    
    errors = 0
    try:
        assert  "name" in dataset[0]
    except AssertionError as e:
        errors += 1
        print("The dataset should return a dict with the name key, identifying geach dataset item")

    try:
        assert  "image" in dataset[0]
    except AssertionError as e:
        errors += 1
        print("The dataset should return a dict with the image key, containing the image to feed the network")

    config_keys = [
        "seed", "log_dir",
        "lr", "epochs", "workers", "batch_size",
        "reset_model", "strat", "budget", "subset", "repetitions", "cycles"
    ] 
    for i in config_keys:
        try:
            assert i in config, f"key {i} not present in config"
        except AssertionError as e:
            print(e)
            errors += 1
            print("The config should have the following keys: ", i)

    
    if precomputed_features is not None:
        try: 
            assert os.path.exists(
            precomputed_features
        ), f"{precomputed_features} doesn't exists. There are only : {os.listdir(precomputed_features.split('/')[:-1])}"
        except AssertionError as e:
            print(e)
            print(f"{precomputed_features} doesn't exists. There are only : {os.listdir(precomputed_features.split('/')[:-1])}")
            errors += 1

    try:
        assert hasattr(lightning_module, "prepare_batch")
    except AssertionError as e:
        print("The lightning module should have a prepare_batch method")
        errors += 1
    
    try:
        assert hasattr(lightning_module, "model")
    except AssertionError as e:
        print("The lightning module should have a model attribute")
        errors += 1

    try:    
        assert hasattr(lightning_module, "forward_proba")
    except AssertionError as e:
        print("The lightning module should have a forward_proba method")
        errors += 1


    try:    
        assert hasattr(lightning_module, "forward_embedding")
    except AssertionError as e:
        print("The lightning module should have a forward_embedding method")
        errors += 1

    assert errors == 0, f"There are {errors} errors in the configuration, please check the output above"
    
