from torch.utils.data import Dataset, Subset


import pandas as pd
import cv2
from PIL import Image
import numpy as np
class UnlabeledDataset(Dataset):
    def __init__(self, path, condition):
        super().__init__()

        self.path = path
        
    @property
    def names(self):
        return np.arange(len(self.path))

    def __len__(self):
        return len(self.path)
    
    def __getitem__(self, idx):
        img = Image.open(self.path[idx])
        return img
